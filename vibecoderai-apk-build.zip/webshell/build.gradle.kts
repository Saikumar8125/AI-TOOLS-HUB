// Tiny WebView shell. Its APK is embedded into the main app as assets/webshell.apk;
// VibeCoderAI injects a project's files into it and signs it on the phone.
plugins {
  alias(libs.plugins.android.application)
}

android {
  namespace = "com.vibecoder.webshell"
  compileSdk { version = release(36) { minorApiLevel = 1 } }

  defaultConfig {
    applicationId = "com.vibecoder.webapp"
    minSdk = 24
    // 28 keeps resources.arsc free of the Android 11+ "stored + aligned" requirement,
    // so the APK can be repackaged with plain java.util.zip.
    targetSdk = 28
    versionCode = 1
    versionName = "1.0"
  }
}
