package com.example.terminal

import com.example.security.SecurityManager
import com.example.security.ValidationResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

data class TerminalExecutionResult(
  val command: String,
  val exitCode: Int,
  val stdout: String,
  val stderr: String,
  val durationMs: Long,
  val timedOut: Boolean = false,
  val blockedReason: String? = null
)

class TerminalManager(
  private val securityManager: SecurityManager = SecurityManager()
) {

  suspend fun executeCommand(
    command: String,
    workspaceDir: File,
    timeoutMs: Long = 10000L
  ): TerminalExecutionResult = withContext(Dispatchers.IO) {
    val startTime = System.currentTimeMillis()

    // 1. Security validation
    when (val validation = securityManager.validateCommand(command, workspaceDir)) {
      is ValidationResult.Blocked -> {
        return@withContext TerminalExecutionResult(
          command = command,
          exitCode = 126,
          stdout = "",
          stderr = "Security Error: ${validation.reason}",
          durationMs = 0,
          blockedReason = validation.reason
        )
      }
      else -> { /* Proceed */ }
    }

    if (!workspaceDir.exists()) {
      workspaceDir.mkdirs()
    }

    // 2. Try executing via internal sandboxed shell first for standard workspace commands
    val internalResult = tryExecuteInternalCommand(command, workspaceDir)
    if (internalResult != null) {
      val duration = System.currentTimeMillis() - startTime
      return@withContext internalResult.copy(durationMs = duration)
    }

    // 3. Fallback to process execution with timeout and cancellation
    val timedResult = withTimeoutOrNull(timeoutMs) {
      try {
        val process = ProcessBuilder()
          .command("sh", "-c", command)
          .directory(workspaceDir)
          .redirectErrorStream(false)
          .start()

        val stdoutSb = StringBuilder()
        val stderrSb = StringBuilder()

        val stdoutReader = BufferedReader(InputStreamReader(process.inputStream))
        val stderrReader = BufferedReader(InputStreamReader(process.errorStream))

        val outThread = Thread {
          try {
            stdoutReader.forEachLine { line -> stdoutSb.appendLine(line) }
          } catch (_: Exception) {}
        }
        val errThread = Thread {
          try {
            stderrReader.forEachLine { line -> stderrSb.appendLine(line) }
          } catch (_: Exception) {}
        }

        outThread.start()
        errThread.start()

        val exitCode = process.waitFor()
        outThread.join(500)
        errThread.join(500)

        TerminalExecutionResult(
          command = command,
          exitCode = exitCode,
          stdout = stdoutSb.toString().trimEnd(),
          stderr = stderrSb.toString().trimEnd(),
          durationMs = System.currentTimeMillis() - startTime
        )
      } catch (e: Exception) {
        TerminalExecutionResult(
          command = command,
          exitCode = 1,
          stdout = "",
          stderr = "Process Execution Error: ${e.message}",
          durationMs = System.currentTimeMillis() - startTime
        )
      }
    }

    timedResult ?: TerminalExecutionResult(
      command = command,
      exitCode = 124,
      stdout = "",
      stderr = "Command execution timed out after ${timeoutMs / 1000} seconds.",
      durationMs = timeoutMs,
      timedOut = true
    )
  }

  private fun tryExecuteInternalCommand(rawCommand: String, workspace: File): TerminalExecutionResult? {
    val tokens = rawCommand.trim().split(Regex("\\s+"))
    if (tokens.isEmpty()) return null
    val cmd = tokens[0]
    val args = tokens.drop(1)

    return when (cmd) {
      "pwd" -> TerminalExecutionResult(
        command = rawCommand,
        exitCode = 0,
        stdout = workspace.absolutePath,
        stderr = "",
        durationMs = 0
      )
      "ls" -> {
        val targetDir = if (args.isNotEmpty() && !args.last().startsWith("-")) {
          File(workspace, args.last())
        } else workspace

        if (!securityManager.isPathSafe(targetDir, workspace)) {
          return TerminalExecutionResult(rawCommand, 1, "", "ls: Access denied outside workspace", 0)
        }

        if (!targetDir.exists()) {
          return TerminalExecutionResult(rawCommand, 2, "", "ls: ${targetDir.name}: No such file or directory", 0)
        }

        val showAll = args.any { it.contains("a") }
        val longFormat = args.any { it.contains("l") }

        val files = targetDir.listFiles()?.filter { showAll || !it.name.startsWith(".") } ?: emptyList()
        val out = if (longFormat) {
          files.joinToString("\n") { file ->
            val type = if (file.isDirectory) "d" else "-"
            val size = file.length()
            val name = if (file.isDirectory) "${file.name}/" else file.name
            "$type rwxr-xr-x 1 user staff $size $name"
          }
        } else {
          files.joinToString("  ") { if (it.isDirectory) "${it.name}/" else it.name }
        }

        TerminalExecutionResult(rawCommand, 0, out, "", 0)
      }
      "cat" -> {
        if (args.isEmpty()) return TerminalExecutionResult(rawCommand, 1, "", "cat: missing file operand", 0)
        val file = File(workspace, args[0])
        if (!securityManager.isPathSafe(file, workspace)) {
          return TerminalExecutionResult(rawCommand, 1, "", "cat: Access denied outside workspace", 0)
        }
        if (!file.exists() || file.isDirectory) {
          return TerminalExecutionResult(rawCommand, 1, "", "cat: ${args[0]}: No such file", 0)
        }
        TerminalExecutionResult(rawCommand, 0, file.readText(), "", 0)
      }
      "echo" -> {
        val text = args.joinToString(" ").removeSurrounding("\"").removeSurrounding("'")
        TerminalExecutionResult(rawCommand, 0, text, "", 0)
      }
      "mkdir" -> {
        if (args.isEmpty()) return TerminalExecutionResult(rawCommand, 1, "", "mkdir: missing operand", 0)
        val dir = File(workspace, args.last())
        if (!securityManager.isPathSafe(dir, workspace)) {
          return TerminalExecutionResult(rawCommand, 1, "", "mkdir: Access denied outside workspace", 0)
        }
        val ok = dir.mkdirs()
        TerminalExecutionResult(rawCommand, if (ok || dir.exists()) 0 else 1, "", if (ok || dir.exists()) "" else "mkdir: cannot create directory", 0)
      }
      "find" -> {
        val found = workspace.walkTopDown().maxDepth(4).map { it.relativeTo(workspace).path }.filter { it.isNotEmpty() }
        TerminalExecutionResult(rawCommand, 0, found.joinToString("\n"), "", 0)
      }
      "git" -> {
        if (args.firstOrNull() == "status") {
          val files = workspace.walkTopDown().filter { it.isFile }.toList()
          TerminalExecutionResult(
            rawCommand,
            0,
            "On branch main\nWorkspace clean: ${files.size} project files tracked.",
            "",
            0
          )
        } else null
      }
      else -> null
    }
  }
}
