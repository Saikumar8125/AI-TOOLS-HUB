package com.example.data.model

enum class MessageSender {
  USER,
  AGENT,
  SYSTEM,
  TOOL
}

data class ToolCallInfo(
  val toolName: String,
  val arguments: Map<String, String>,
  val status: String = "running", // running, success, error
  val resultSummary: String? = null
)

enum class ChangeStatus { PENDING, APPLIED, DISCARDED, FAILED }

/** A file the model wants to create or overwrite. */
data class FileChange(
  val path: String,
  val content: String,
  val isNew: Boolean,
  val status: ChangeStatus = ChangeStatus.PENDING,
  val error: String? = null
) {
  val lineCount: Int get() = content.count { it == '\n' } + 1
}

data class ChatMessage(
  val id: String,
  val sender: MessageSender,
  val content: String,
  val timestamp: Long = System.currentTimeMillis(),
  val toolCall: ToolCallInfo? = null,
  val patchProposal: PatchProposal? = null,
  val isStreaming: Boolean = false,
  val thoughts: String? = null,
  val fileChanges: List<FileChange> = emptyList()
)
