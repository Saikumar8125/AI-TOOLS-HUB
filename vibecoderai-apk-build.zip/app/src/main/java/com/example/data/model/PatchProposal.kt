package com.example.data.model

data class PatchProposal(
  val id: String,
  val targetFilePath: String,
  val relativePath: String,
  val startLine: Int,
  val endLine: Int,
  val originalContent: String,
  val replacementContent: String,
  val rationale: String,
  val isApproved: Boolean = false,
  val isApplied: Boolean = false,
  val timestamp: Long = System.currentTimeMillis()
) {
  val diffLines: List<DiffLine> by lazy {
    generateDiff(originalContent, replacementContent)
  }

  companion object {
    fun generateDiff(original: String, replacement: String): List<DiffLine> {
      val origLines = if (original.isEmpty()) emptyList() else original.lines()
      val replLines = if (replacement.isEmpty()) emptyList() else replacement.lines()
      val diffs = mutableListOf<DiffLine>()

      origLines.forEachIndexed { idx, line ->
        diffs.add(DiffLine(type = DiffType.REMOVED, content = line, lineNumber = idx + 1))
      }
      replLines.forEachIndexed { idx, line ->
        diffs.add(DiffLine(type = DiffType.ADDED, content = line, lineNumber = idx + 1))
      }
      return diffs
    }
  }
}

enum class DiffType {
  UNCHANGED,
  ADDED,
  REMOVED
}

data class DiffLine(
  val type: DiffType,
  val content: String,
  val lineNumber: Int
)
