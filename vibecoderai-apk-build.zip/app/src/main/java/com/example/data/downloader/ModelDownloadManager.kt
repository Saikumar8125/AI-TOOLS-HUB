package com.example.data.downloader

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** In-process GGUF downloader with progress, pause and resume (HTTP Range). No background service. */
class ModelDownloadManager(private val modelsDir: File) {

  enum class State { RUNNING, PAUSED, DONE, FAILED }

  data class Item(
    val key: String,
    val modelId: String,
    val fileName: String,
    val total: Long,
    val downloaded: Long,
    val state: State,
    val error: String? = null
  ) {
    val destName: String get() = fileName.substringAfterLast('/')
    val fraction: Float get() = if (total > 0) (downloaded.toFloat() / total).coerceIn(0f, 1f) else 0f
  }

  private val _items = MutableStateFlow<Map<String, Item>>(emptyMap())
  val items: StateFlow<Map<String, Item>> = _items.asStateFlow()
  private val jobs = mutableMapOf<String, Job>()

  fun key(modelId: String, file: HfFile) = "$modelId/${file.name}"

  /** Starts a download, or resumes a paused/failed one from the bytes already on disk. */
  @Synchronized
  fun start(scope: CoroutineScope, modelId: String, file: HfFile) {
    val k = key(modelId, file)
    if (jobs[k]?.isActive == true) return
    val base = _items.value[k] ?: Item(k, modelId, file.name, file.sizeBytes, 0L, State.RUNNING)
    _items.update { it + (k to base.copy(state = State.RUNNING, error = null)) }
    jobs[k] = scope.launch(Dispatchers.IO) { run(k) }
  }

  @Synchronized
  fun pause(key: String) {
    jobs[key]?.cancel()
  }

  /** Stops the download and deletes the partial file. */
  @Synchronized
  fun cancel(key: String) {
    val item = _items.value[key]
    jobs.remove(key)?.cancel()
    _items.update { it - key }
    if (item != null) File(modelsDir, item.destName + ".part").delete()
  }

  fun dismiss(key: String) {
    _items.update { it - key }
  }

  private fun setItem(key: String, change: (Item) -> Item) {
    _items.update { map -> map[key]?.let { map + (key to change(it)) } ?: map }
  }

  private suspend fun run(key: String) {
    val item = _items.value[key] ?: return
    val dest = File(modelsDir, item.destName)
    val part = File(modelsDir, item.destName + ".part")
    modelsDir.mkdirs()
    var conn: HttpURLConnection? = null
    try {
      var done = if (part.exists()) part.length() else 0L
      if (item.total > 0 && modelsDir.usableSpace < item.total - done + 100L * 1024 * 1024) {
        throw IOException("Not enough free storage.")
      }

      val url = "${HuggingFaceApi.BASE}/${item.modelId}/resolve/main/${item.fileName.replace(" ", "%20")}"
      conn = (URL(url).openConnection() as HttpURLConnection).apply {
        connectTimeout = 15_000
        readTimeout = 30_000
        setRequestProperty("User-Agent", HuggingFaceApi.USER_AGENT)
        if (done > 0) setRequestProperty("Range", "bytes=$done-")
      }
      val code = conn.responseCode
      if (code != 200 && code != 206) throw IOException("Download failed: HTTP $code")
      if (code == 200 && done > 0) {
        // Server ignored the Range header: start over.
        part.delete()
        done = 0L
      }
      val total = if (item.total > 0) item.total else done + conn.contentLengthLong
      setItem(key) { it.copy(total = total, downloaded = done) }

      var lastUi = 0L
      conn.inputStream.use { input ->
        FileOutputStream(part, done > 0).use { out ->
          val buf = ByteArray(256 * 1024)
          while (true) {
            val n = input.read(buf)
            if (n < 0) break
            currentCoroutineContext().ensureActive()
            out.write(buf, 0, n)
            done += n
            val now = System.currentTimeMillis()
            if (now - lastUi > 300) {
              lastUi = now
              setItem(key) { it.copy(downloaded = done) }
            }
          }
        }
      }

      if (total > 0 && part.length() < total) throw IOException("Connection closed early. Tap Resume.")
      if (dest.exists()) dest.delete()
      if (!part.renameTo(dest)) throw IOException("Could not save the model file.")
      setItem(key) { it.copy(downloaded = it.total, state = State.DONE) }
    } catch (e: CancellationException) {
      setItem(key) { it.copy(state = State.PAUSED, downloaded = if (part.exists()) part.length() else 0L) }
    } catch (e: Exception) {
      setItem(key) { it.copy(state = State.FAILED, error = e.message ?: e.javaClass.simpleName) }
    } finally {
      conn?.disconnect()
    }
  }
}
