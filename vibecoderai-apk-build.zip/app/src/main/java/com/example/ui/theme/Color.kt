package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Neutral graphite surfaces with one restrained blue accent. (Constant names kept for compatibility.)
val ObsidianBackground = Color(0xFF0F1115)
val ObsidianSurface = Color(0xFF16181D)
val ObsidianSurfaceVariant = Color(0xFF1F2228)
val ObsidianBorder = Color(0xFF2B2F37)

// Accent
val CyberCyanPrimary = Color(0xFF7AA2F7)
val CyberCyanContainer = Color(0xFF1F2B45)
val CyberOnCyan = Color(0xFF0F1115)

val CyberVioletSecondary = Color(0xFF9AA5CE)
val CyberVioletContainer = Color(0xFF262A3D)

// Status
val CyberGreenSuccess = Color(0xFF7BC88F)
val CyberGreenContainer = Color(0xFF1B2E23)

val CyberAmberWarning = Color(0xFFE0AF68)
val CyberAmberContainer = Color(0xFF33291A)

val CyberCoralError = Color(0xFFE5707A)
val CyberCoralContainer = Color(0xFF3A2024)

// Text
val TextPrimary = Color(0xFFE4E6EB)
val TextSecondary = Color(0xFF9AA0AA)
val TextMuted = Color(0xFF6C727D)

// Code and diffs
val CodeBackground = Color(0xFF0B0D10)
val DiffAddedBg = Color(0xFF14261C)
val DiffRemovedBg = Color(0xFF2B181B)
val DiffAddedText = Color(0xFF8FD6A1)
val DiffRemovedText = Color(0xFFF0A0A8)
