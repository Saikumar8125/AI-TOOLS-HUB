package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.AgentOrchestrator
import com.example.agent.SelfRepairEngine
import com.example.build.BuildRunner
import com.example.data.SettingsStore
import com.example.data.model.SettingsState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.example.llama.LlamaEngine
import com.example.project.ProjectManager
import com.example.terminal.TerminalManager
import com.example.testing.TestRunnerEngine
import com.example.ui.screens.AgentScreen
import com.example.ui.screens.WebPreviewScreen
import com.example.ui.screens.BuildScreen
import com.example.ui.screens.ModelsScreen
import com.example.data.downloader.ModelDownloadManager
import com.example.data.local.ChatStore
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import com.example.ui.screens.ProjectScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TerminalScreen
import com.example.ui.screens.TestsScreen
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

enum class AppDestination(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
  AGENT("Chat", Icons.Default.SmartToy),
  PROJECT("Projects", Icons.Default.Folder),
  MODELS("Models", Icons.Default.Memory),
  TERMINAL("Terminal", Icons.Default.Terminal),
  SETTINGS("Settings", Icons.Default.Settings),
  BUILD("Build", Icons.Default.Build)
}

@Composable
fun MainScreen() {
  val context = LocalContext.current

  // Shared instances
  val projectManager = remember { ProjectManager(context) }
  val terminalManager = remember { TerminalManager() }
  val buildRunner = remember { BuildRunner() }
  val selfRepairEngine = remember { SelfRepairEngine(buildRunner = buildRunner) }
  val testRunnerEngine = remember { TestRunnerEngine(context = context, buildRunner = buildRunner, terminalManager = terminalManager) }
  val llamaEngine = remember { LlamaEngine(context) }

  val settingsStore = remember { SettingsStore(context) }
  val scope = rememberCoroutineScope()
  var settings by remember { mutableStateOf(settingsStore.load()) }
  var modelLoaded by remember { mutableStateOf(false) }
  var modelStatus by remember { mutableStateOf<String?>("Loading model...") }
  val orchestrator = remember {
    AgentOrchestrator(
      context = context,
      llamaEngine = llamaEngine,
      selfRepairEngine = selfRepairEngine
    )
  }

  val downloads = remember { ModelDownloadManager(llamaEngine.modelsDir()) }
  val chatStore = remember { ChatStore(context) }

  // Restore chat history, then persist changes (debounced)
  LaunchedEffect(Unit) {
    val saved = withContext(Dispatchers.IO) { chatStore.load() }
    orchestrator.restore(saved)
    orchestrator.messages.collectLatest { msgs ->
      delay(1000)
      withContext(Dispatchers.IO) { chatStore.save(msgs) }
    }
  }

  // Initialize projects and llama model
  LaunchedEffect(Unit) {
    com.example.build.ApkPackager.appContext = context.applicationContext
    projectManager.initialize()
    withContext(Dispatchers.IO) { llamaEngine.initialize(settings) }
    modelLoaded = llamaEngine.isReady
    modelStatus = llamaEngine.statusMessage
  }

  val activeProject by projectManager.activeProject.collectAsState()

  var currentDestination by remember { mutableStateOf(AppDestination.AGENT) }
  var isViewingTests by remember { mutableStateOf(false) }
  var isPreviewing by remember { mutableStateOf(false) }

  BackHandler(enabled = isPreviewing || isViewingTests || currentDestination != AppDestination.AGENT) {
    if (isPreviewing) {
      isPreviewing = false
    } else if (isViewingTests) {
      isViewingTests = false
    } else {
      currentDestination = AppDestination.AGENT
    }
  }

  Scaffold(
    modifier = Modifier
      .fillMaxSize()
      .statusBarsPadding(),
    bottomBar = {
      if (!isViewingTests) {
        NavigationBar(
          containerColor = ObsidianSurface,
          tonalElevation = 8.dp,
          modifier = Modifier.navigationBarsPadding()
        ) {
          AppDestination.values().filter { it != AppDestination.BUILD }.forEach { destination ->
            val isSelected = currentDestination == destination
            NavigationBarItem(
              selected = isSelected,
              onClick = { currentDestination = destination },
              icon = {
                Icon(
                  imageVector = destination.icon,
                  contentDescription = destination.label
                )
              },
              label = {
                Text(
                  text = destination.label,
                  fontSize = 11.sp
                )
              },
              colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyberCyanPrimary,
                selectedTextColor = CyberCyanPrimary,
                indicatorColor = CyberCyanContainer,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted
              )
            )
          }
        }
      }
    }
  ) { paddingValues ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
    ) {
      val previewProject = activeProject
      if (isPreviewing && previewProject != null) {
        WebPreviewScreen(
          project = previewProject,
          onBack = { isPreviewing = false },
          onFixErrors = { errors ->
            isPreviewing = false
            currentDestination = AppDestination.AGENT
            orchestrator.sendMessage(
              "Fix these JavaScript errors in the app. Output only the files that change.\n$errors",
              previewProject,
              settings,
              scope
            )
          }
        )
      } else if (isViewingTests) {
        TestsScreen(
          testRunnerEngine = testRunnerEngine,
          activeProject = activeProject,
          onBack = { isViewingTests = false }
        )
      } else {
        when (currentDestination) {
          AppDestination.AGENT -> {
            AgentScreen(
              orchestrator = orchestrator,
              projectManager = projectManager,
              activeProject = activeProject,
              settings = settings,
              onPreview = { isPreviewing = true },
              onOpenBuild = { currentDestination = AppDestination.BUILD }
            )
          }
          AppDestination.PROJECT -> {
            ProjectScreen(
              projectManager = projectManager
            )
          }
          AppDestination.MODELS -> {
            ModelsScreen(
              modelsDir = llamaEngine.modelsDir(),
              currentPath = settings.customModelPath,
              modelLoaded = modelLoaded,
              modelStatus = modelStatus,
              downloads = downloads,
              onSelectModel = { path ->
                val updated = settings.copy(customModelPath = path)
                settings = updated
                settingsStore.save(updated)
                modelLoaded = false
                modelStatus = "Loading model..."
                scope.launch {
                  withContext(Dispatchers.IO) { llamaEngine.initialize(updated) }
                  modelLoaded = llamaEngine.isReady
                  modelStatus = llamaEngine.statusMessage
                }
              },
              onUnload = {
                scope.launch {
                  withContext(Dispatchers.IO) { llamaEngine.unload() }
                  modelLoaded = false
                  modelStatus = llamaEngine.statusMessage
                }
              }
            )
          }
          AppDestination.TERMINAL -> {
            TerminalScreen(
              terminalManager = terminalManager,
              activeProject = activeProject
            )
          }
          AppDestination.BUILD -> {
            BuildScreen(
              buildRunner = buildRunner,
              selfRepairEngine = selfRepairEngine,
              activeProject = activeProject,
              onNavigateToAgent = { currentDestination = AppDestination.AGENT }
            )
          }
          AppDestination.SETTINGS -> {
            SettingsScreen(
              settings = settings,
              onUpdateSettings = {
                settings = it
                settingsStore.save(it)
              },
              onOpenTestRunner = { isViewingTests = true }
            )
          }
        }
      }
    }
  }
}
