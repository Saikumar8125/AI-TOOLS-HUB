package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TelemetryData
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

@Composable
fun TelemetryBar(
  telemetry: TelemetryData,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(6.dp))
      .background(ObsidianSurfaceVariant)
      .padding(horizontal = 12.dp, vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    // Tokens per second
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(
        imageVector = Icons.Default.Speed,
        contentDescription = "Inference Speed",
        tint = CyberCyanPrimary,
        modifier = Modifier.padding(end = 4.dp)
      )
      Text(
        text = String.format("%.1f t/s", telemetry.tokensPerSecond),
        color = TextPrimary,
        fontSize = 11.sp,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.SemiBold
      )
    }

    // Token Count
    Row(verticalAlignment = Alignment.CenterVertically) {
      Text(
        text = "Tokens: ${telemetry.inputTokens} in / ${telemetry.outputTokens} out",
        color = TextMuted,
        fontSize = 11.sp,
        fontFamily = FontFamily.Monospace
      )
    }

    // RAM / Memory
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(
        imageVector = Icons.Default.Memory,
        contentDescription = "Memory",
        tint = CyberGreenSuccess,
        modifier = Modifier.padding(end = 4.dp)
      )
      Text(
        text = "${telemetry.usedRamMb}MB RAM",
        color = TextPrimary,
        fontSize = 11.sp,
        fontFamily = FontFamily.Monospace
      )
    }
  }
}
