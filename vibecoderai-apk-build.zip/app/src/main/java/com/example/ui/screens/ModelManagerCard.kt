package com.example.ui.screens

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.llama.LlamaBridge
import com.example.ui.theme.CyberAmberWarning
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

private fun listModels(dir: File): List<File> =
  dir.listFiles { f -> f.isFile && f.name.endsWith(".gguf", ignoreCase = true) }
    ?.sortedBy { it.name.lowercase() }
    ?: emptyList()

private fun importModel(context: Context, uri: Uri, dir: File): Result<File> = runCatching {
  val resolver = context.contentResolver
  var name = "model.gguf"
  var size = -1L
  resolver.query(uri, null, null, null, null)?.use { c ->
    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
    val si = c.getColumnIndex(OpenableColumns.SIZE)
    if (c.moveToFirst()) {
      if (ni >= 0) name = c.getString(ni) ?: name
      if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
    }
  }
  name = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
  if (!name.endsWith(".gguf", ignoreCase = true)) {
    throw IllegalArgumentException("Please pick a .gguf model file.")
  }
  dir.mkdirs()
  if (size > 0 && dir.usableSpace < size + 64L * 1024 * 1024) {
    throw IllegalStateException("Not enough free storage for this model.")
  }

  val tmp = File(dir, "$name.part")
  val dest = File(dir, name)
  try {
    val input = resolver.openInputStream(uri) ?: throw IOException("Cannot open the selected file.")
    input.use { ins -> FileOutputStream(tmp).use { out -> ins.copyTo(out, 1 shl 20) } }

    val magic = ByteArray(4)
    tmp.inputStream().use { it.read(magic) }
    if (String(magic, Charsets.US_ASCII) != "GGUF") {
      throw IllegalArgumentException("This file is not a valid GGUF model.")
    }
    if (dest.exists()) dest.delete()
    if (!tmp.renameTo(dest)) throw IOException("Could not save the model file.")
  } finally {
    if (tmp.exists()) tmp.delete()
  }
  dest
}

private fun formatSize(bytes: Long): String =
  if (bytes >= 1_000_000_000L) "%.2f GB".format(bytes / 1_000_000_000.0) else "${bytes / 1_000_000} MB"

@Composable
fun ModelManagerCard(
  modelsDir: File,
  currentPath: String?,
  modelLoaded: Boolean,
  modelStatus: String?,
  onSelectModel: (String?) -> Unit,
  refreshKey: Int = 0
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  var files by remember(refreshKey) { mutableStateOf(listModels(modelsDir)) }
  var importing by remember { mutableStateOf(false) }
  var message by remember { mutableStateOf<String?>(null) }

  val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
    if (uri != null) {
      importing = true
      message = "Importing model... this can take a minute for large files."
      scope.launch {
        val result = withContext(Dispatchers.IO) { importModel(context, uri, modelsDir) }
        importing = false
        files = listModels(modelsDir)
        result
          .onSuccess { f ->
            message = "Imported ${f.name}"
            onSelectModel(f.absolutePath)
          }
          .onFailure { e -> message = e.message ?: "Import failed" }
      }
    }
  }

  Card(
    shape = RoundedCornerShape(8.dp),
    colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Text("OFFLINE AI MODEL (GGUF)", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
      Spacer(modifier = Modifier.height(6.dp))

      // Engine status
      val statusColor = when {
        !LlamaBridge.isNativeLoaded -> CyberCoralError
        modelLoaded -> CyberGreenSuccess
        else -> CyberAmberWarning
      }
      val statusText = when {
        !LlamaBridge.isNativeLoaded -> "llama.cpp library failed to load: ${LlamaBridge.nativeLoadError ?: "unknown error"}"
        modelLoaded -> "Model loaded. Running fully offline on CPU."
        else -> modelStatus ?: "No model loaded. Import a .gguf file."
      }
      Text(statusText, color = statusColor, fontSize = 12.sp)

      Spacer(modifier = Modifier.height(8.dp))

      Button(
        onClick = { picker.launch(arrayOf("*/*")) },
        enabled = !importing,
        colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.Black),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Text(if (importing) "Importing..." else "Import GGUF model", fontWeight = FontWeight.Bold, fontSize = 13.sp)
      }

      message?.let {
        Spacer(modifier = Modifier.height(6.dp))
        Text(it, color = TextPrimary, fontSize = 11.sp)
      }

      Spacer(modifier = Modifier.height(8.dp))

      if (files.isEmpty()) {
        Text(
          "No models imported yet. Recommended for phones with 6 GB RAM: a coder model of 1.5B-3B parameters in Q4_K_M " +
            "(for example Qwen2.5-Coder-1.5B-Instruct-Q4_K_M.gguf, ~1 GB). Download it once, then import it here.",
          color = TextMuted,
          fontSize = 11.sp
        )
      }

      files.forEach { f ->
        val isSelected = f.absolutePath == currentPath
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(if (isSelected) ObsidianSurfaceVariant else Color.Transparent)
            .clickable { onSelectModel(f.absolutePath) }
            .padding(6.dp)
        ) {
          RadioButton(selected = isSelected, onClick = { onSelectModel(f.absolutePath) })
          Spacer(modifier = Modifier.width(4.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              f.name,
              color = if (isSelected) CyberCyanPrimary else TextPrimary,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
            Text(formatSize(f.length()), color = TextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
          }
          IconButton(onClick = {
            val wasSelected = isSelected
            f.delete()
            files = listModels(modelsDir)
            if (wasSelected) onSelectModel(null)
          }) {
            Icon(Icons.Default.Delete, contentDescription = "Delete ${f.name}", tint = CyberCoralError, modifier = Modifier.size(18.dp))
          }
        }
      }
    }
  }
}
