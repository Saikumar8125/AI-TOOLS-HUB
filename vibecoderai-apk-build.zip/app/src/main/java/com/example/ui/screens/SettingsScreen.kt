package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ModelBackend
import com.example.data.model.SettingsState
import com.example.llama.LlamaBridge
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.CyberVioletSecondary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

@Composable
fun SettingsScreen(
  settings: SettingsState,
  onUpdateSettings: (SettingsState) -> Unit,
  onOpenTestRunner: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val scrollState = rememberScrollState()

  val runtime = Runtime.getRuntime()
  var usedMb by remember { mutableStateOf((runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)) }
  var totalMb by remember { mutableStateOf(runtime.totalMemory() / (1024 * 1024)) }
  var maxMb by remember { mutableStateOf(runtime.maxMemory() / (1024 * 1024)) }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .verticalScroll(scrollState)
      .padding(14.dp)
  ) {
    // Top Title and Test Runner banner
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(imageVector = Icons.Default.Settings, contentDescription = null, tint = CyberCyanPrimary, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Engine & Hardware Settings", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
      }

      Button(
        onClick = onOpenTestRunner,
        colors = ButtonDefaults.buttonColors(containerColor = CyberVioletSecondary, contentColor = Color.Black),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.testTag("open_test_runner_button")
      ) {
        Icon(imageVector = Icons.Default.Science, contentDescription = null, modifier = Modifier.size(14.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("Run Tests", fontSize = 11.sp, fontWeight = FontWeight.Bold)
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // 3. CPU Threads & Sampling Settings
    Card(
      shape = RoundedCornerShape(8.dp),
      colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        Text("SAMPLING & THREAD CONFIGURATION", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        // CPU Threads
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("CPU Threads: ${settings.cpuThreads}", color = TextPrimary, fontSize = 13.sp)
          Text("${Runtime.getRuntime().availableProcessors()} Cores Available", color = TextMuted, fontSize = 11.sp)
        }
        Slider(
          value = settings.cpuThreads.toFloat(),
          onValueChange = { onUpdateSettings(settings.copy(cpuThreads = it.toInt())) },
          valueRange = 1f..8f,
          steps = 6,
          colors = SliderDefaults.colors(thumbColor = CyberCyanPrimary, activeTrackColor = CyberCyanPrimary)
        )

        // Context Length
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Context Window: ${settings.contextLength} tokens", color = TextPrimary, fontSize = 13.sp)
        }
        Slider(
          value = settings.contextLength.toFloat(),
          onValueChange = { onUpdateSettings(settings.copy(contextLength = it.toInt())) },
          valueRange = 1024f..8192f,
          steps = 6,
          colors = SliderDefaults.colors(thumbColor = CyberVioletSecondary, activeTrackColor = CyberVioletSecondary)
        )

        // Max Output Tokens
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Max Output Tokens: ${settings.maxOutputTokens}", color = TextPrimary, fontSize = 13.sp)
        }
        Slider(
          value = settings.maxOutputTokens.toFloat(),
          onValueChange = { onUpdateSettings(settings.copy(maxOutputTokens = it.toInt())) },
          valueRange = 256f..2048f,
          steps = 6
        )

        // Temperature
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(String.format("Temperature: %.2f", settings.temperature), color = TextPrimary, fontSize = 13.sp)
        }
        Slider(
          value = settings.temperature,
          onValueChange = { onUpdateSettings(settings.copy(temperature = it)) },
          valueRange = 0.0f..1.0f
        )
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // 4. Memory Monitor & Security Card
    Card(
      shape = RoundedCornerShape(8.dp),
      colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Default.Memory, contentDescription = null, tint = CyberGreenSuccess, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("MEMORY USAGE MONITOR", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }

          Button(
            onClick = {
              System.gc()
              val r = Runtime.getRuntime()
              usedMb = (r.totalMemory() - r.freeMemory()) / (1024 * 1024)
              totalMb = r.totalMemory() / (1024 * 1024)
              Toast.makeText(context, "Garbage collection triggered", Toast.LENGTH_SHORT).show()
            },
            colors = ButtonDefaults.buttonColors(containerColor = ObsidianSurfaceVariant, contentColor = TextPrimary),
            shape = RoundedCornerShape(4.dp)
          ) {
            Icon(imageVector = Icons.Default.CleaningServices, contentDescription = null, modifier = Modifier.size(12.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Free RAM", fontSize = 11.sp)
          }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text("JVM Heap: $usedMb MB used / $totalMb MB total (Max limit: $maxMb MB)", color = TextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)

        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("Security: Require Approval for Patches", color = TextPrimary, fontSize = 13.sp)
          Switch(
            checked = settings.requireApprovalForDestructive,
            onCheckedChange = { onUpdateSettings(settings.copy(requireApprovalForDestructive = it)) },
            colors = SwitchDefaults.colors(checkedThumbColor = CyberCyanPrimary, checkedTrackColor = ObsidianBorder)
          )
        }
      }
    }
  }
}
