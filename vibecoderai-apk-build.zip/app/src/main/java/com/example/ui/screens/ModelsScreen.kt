package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.downloader.HfFile
import com.example.data.downloader.HfModel
import com.example.data.downloader.HuggingFaceApi
import com.example.data.downloader.ModelDownloadManager
import com.example.data.downloader.ModelDownloadManager.State
import com.example.ui.theme.CyberAmberWarning
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private fun fmtSize(b: Long): String =
  if (b >= 1_000_000_000L) "%.2f GB".format(b / 1e9) else "${b / 1_000_000} MB"

private fun fmtCount(n: Long): String = if (n >= 1000) "${n / 1000}k" else n.toString()

@Composable
fun ModelsScreen(
  modelsDir: File,
  currentPath: String?,
  modelLoaded: Boolean,
  modelStatus: String?,
  downloads: ModelDownloadManager,
  onSelectModel: (String?) -> Unit,
  onUnload: () -> Unit,
  modifier: Modifier = Modifier
) {
  val scope = rememberCoroutineScope()
  val items by downloads.items.collectAsState()
  var query by remember { mutableStateOf("qwen2.5 coder instruct") }
  var results by remember { mutableStateOf<List<HfModel>>(emptyList()) }
  var searching by remember { mutableStateOf(false) }
  var error by remember { mutableStateOf<String?>(null) }
  var selected by remember { mutableStateOf<HfModel?>(null) }
  var files by remember { mutableStateOf<List<HfFile>>(emptyList()) }
  var loadingFiles by remember { mutableStateOf(false) }
  val doneCount = items.values.count { it.state == State.DONE }

  fun search() {
    scope.launch {
      searching = true
      error = null
      selected = null
      try {
        results = withContext(Dispatchers.IO) { HuggingFaceApi.search(query) }
        if (results.isEmpty()) error = "No GGUF models found."
      } catch (e: Exception) {
        error = e.message ?: "Search failed. Check your internet connection."
      }
      searching = false
    }
  }

  fun open(m: HfModel) {
    selected = m
    files = emptyList()
    scope.launch {
      loadingFiles = true
      try {
        files = withContext(Dispatchers.IO) { HuggingFaceApi.listGguf(m.id) }
        if (files.isEmpty()) error = "No .gguf files in this repository."
      } catch (e: Exception) {
        error = e.message ?: "Could not load files."
      }
      loadingFiles = false
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .verticalScroll(rememberScrollState())
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    Text("Models", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)

    ModelManagerCard(
      modelsDir = modelsDir,
      currentPath = currentPath,
      modelLoaded = modelLoaded,
      modelStatus = modelStatus,
      onSelectModel = onSelectModel,
      refreshKey = doneCount
    )

    if (modelLoaded) {
      OutlinedButton(onClick = onUnload, modifier = Modifier.fillMaxWidth()) {
        Text("Unload model (free RAM)", color = TextSecondary, fontSize = 13.sp)
      }
    }

    // Active and finished downloads
    if (items.isNotEmpty()) {
      Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text("DOWNLOADS", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          items.values.toList().forEach { item ->
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Text(item.destName, color = TextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
              if (item.state != State.DONE) {
                LinearProgressIndicator(
                  progress = { item.fraction },
                  modifier = Modifier.fillMaxWidth(),
                  color = CyberCyanPrimary,
                  trackColor = ObsidianSurfaceVariant
                )
              }
              val status = when (item.state) {
                State.RUNNING -> "${(item.fraction * 100).toInt()}% · ${fmtSize(item.downloaded)} / ${fmtSize(item.total)}"
                State.PAUSED -> "Paused · ${fmtSize(item.downloaded)} / ${fmtSize(item.total)}"
                State.DONE -> "Downloaded · ${fmtSize(item.total)}"
                State.FAILED -> item.error ?: "Failed"
              }
              val statusColor = when (item.state) {
                State.DONE -> CyberGreenSuccess
                State.FAILED -> CyberCoralError
                State.PAUSED -> CyberAmberWarning
                State.RUNNING -> TextSecondary
              }
              Text(status, color = statusColor, fontSize = 11.sp)
              Row(verticalAlignment = Alignment.CenterVertically) {
                when (item.state) {
                  State.RUNNING -> TextButton(onClick = { downloads.pause(item.key) }) { Text("Pause", fontSize = 12.sp) }
                  State.PAUSED, State.FAILED -> TextButton(onClick = {
                    downloads.start(scope, item.modelId, HfFile(item.fileName, item.total))
                  }) { Text(if (item.state == State.PAUSED) "Resume" else "Retry", fontSize = 12.sp) }
                  State.DONE -> {
                    TextButton(onClick = { onSelectModel(File(modelsDir, item.destName).absolutePath) }) {
                      Text("Use this model", fontSize = 12.sp)
                    }
                    TextButton(onClick = { downloads.dismiss(item.key) }) {
                      Text("Dismiss", fontSize = 12.sp, color = TextSecondary)
                    }
                  }
                }
                if (item.state != State.DONE) {
                  TextButton(onClick = { downloads.cancel(item.key) }) {
                    Text("Cancel", fontSize = 12.sp, color = CyberCoralError)
                  }
                }
              }
            }
          }
        }
      }
    }

    // Hugging Face browser
    Card(
      shape = RoundedCornerShape(8.dp),
      colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("DOWNLOAD FROM HUGGING FACE", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text(
          "Internet is only used here. Inference stays fully offline. Tip: pick Q4_K_M files of 1.5B-3B coder models.",
          color = TextMuted,
          fontSize = 11.sp
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
          OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            modifier = Modifier.weight(1f),
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary,
              focusedBorderColor = CyberCyanPrimary,
              unfocusedBorderColor = ObsidianBorder,
              cursorColor = CyberCyanPrimary
            )
          )
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = { search() },
            enabled = !searching && query.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.Black)
          ) { Text(if (searching) "..." else "Search", fontSize = 13.sp) }
        }

        error?.let { Text(it, color = CyberCoralError, fontSize = 12.sp) }

        results.forEach { m ->
          val isOpen = selected?.id == m.id
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(6.dp))
              .background(if (isOpen) ObsidianSurfaceVariant else Color.Transparent)
              .clickable { open(m) }
              .padding(8.dp)
          ) {
            Text(m.id, color = if (isOpen) CyberCyanPrimary else TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text("${fmtCount(m.downloads)} downloads · ${fmtCount(m.likes)} likes", color = TextMuted, fontSize = 11.sp)
          }
          if (isOpen) {
            if (loadingFiles) Text("Loading files...", color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp))
            files.forEach { f ->
              val k = downloads.key(m.id, f)
              val existing = items[k]
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().padding(start = 8.dp)
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(f.name, color = TextSecondary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                  Text(fmtSize(f.sizeBytes), color = TextMuted, fontSize = 11.sp)
                }
                if (existing == null) {
                  TextButton(onClick = { downloads.start(scope, m.id, f) }) { Text("Download", fontSize = 12.sp) }
                } else {
                  Text("In downloads", color = TextMuted, fontSize = 11.sp)
                }
              }
            }
            Spacer(modifier = Modifier.height(4.dp))
          }
        }
      }
    }
  }
}
