package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.AgentOrchestrator
import com.example.agent.FileBlocks
import com.example.data.model.ChatMessage
import com.example.data.model.MessageSender
import com.example.data.model.Project
import com.example.data.model.SettingsState
import com.example.data.model.TelemetryData
import com.example.project.ProjectManager
import com.example.project.createBlankWebProject
import com.example.ui.components.DiffViewer
import com.example.ui.components.FileChangesCard
import com.example.ui.components.MarkdownText
import com.example.ui.components.PatchApprovalDialog
import com.example.ui.components.TelemetryBar
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val SUGGESTIONS = listOf(
  "Todo list with local storage",
  "Scientific calculator",
  "Pomodoro timer with sound",
  "Expense tracker with a bar chart"
)

@Composable
fun AgentScreen(
  orchestrator: AgentOrchestrator,
  projectManager: ProjectManager,
  activeProject: Project?,
  settings: SettingsState,
  onPreview: () -> Unit,
  onOpenBuild: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  val messages by orchestrator.messages.collectAsState()
  val telemetry by orchestrator.telemetry.collectAsState()
  val pendingPatch by orchestrator.pendingPatch.collectAsState()
  val isGenerating by orchestrator.isGenerating.collectAsState()

  var inputText by remember { mutableStateOf("") }
  val listState = rememberLazyListState()
  val scope = rememberCoroutineScope()

  val writtenCount = messages.count { m -> m.fileChanges.any { it.status == com.example.data.model.ChangeStatus.APPLIED } }
  val canPreview = remember(activeProject?.id, writtenCount) {
    activeProject != null && File(activeProject.rootDir, "index.html").isFile
  }

  LaunchedEffect(messages.size) {
    if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
  }
  LaunchedEffect(messages.lastOrNull()?.content?.length) {
    if (isGenerating && messages.isNotEmpty()) listState.scrollToItem(messages.lastIndex, 100_000)
  }

  pendingPatch?.let { patch ->
    if (activeProject != null) {
      PatchApprovalDialog(
        proposal = patch,
        onApprove = { orchestrator.approveAndApplyPatch(patch, activeProject, scope) },
        onReject = { orchestrator.rejectPatch(patch) }
      )
    }
  }

  fun submit(raw: String) {
    val text = raw.trim()
    if (text.isEmpty() || isGenerating) return
    inputText = ""
    scope.launch {
      val project = activeProject ?: withContext(Dispatchers.IO) { projectManager.createBlankWebProject(text) }
      orchestrator.sendMessage(text, project, settings, scope)
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    TelemetryBar(
      telemetry = telemetry,
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
    )

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(start = 16.dp, end = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = activeProject?.name ?: "No project yet",
        color = if (activeProject != null) TextPrimary else TextMuted,
        fontSize = 13.sp,
        fontFamily = FontFamily.Monospace,
        modifier = Modifier.weight(1f)
      )
      if (messages.size > 1 && !isGenerating) {
        TextButton(onClick = { orchestrator.newChat() }) {
          Text("New chat", fontSize = 13.sp, color = TextSecondary)
        }
      }
      TextButton(onClick = onOpenBuild) {
        Text("Build", fontSize = 13.sp, color = TextSecondary)
      }
      if (canPreview) {
        TextButton(onClick = onPreview) {
          Text("Preview", fontSize = 13.sp, color = CyberCyanPrimary, fontWeight = FontWeight.SemiBold)
        }
      }
    }

    LazyColumn(
      state = listState,
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
      contentPadding = PaddingValues(vertical = 8.dp)
    ) {
      items(messages, key = { it.id }) { message ->
        MessageItem(
          message = message,
          telemetry = telemetry,
          canPreview = canPreview,
          onApply = { if (activeProject != null) orchestrator.applyChanges(message.id, activeProject, scope) },
          onDiscard = { orchestrator.discardChanges(message.id) },
          onPreview = onPreview,
          onApplyPatch = { patch ->
            if (activeProject != null) orchestrator.approveAndApplyPatch(patch, activeProject, scope)
          }
        )
      }
      if (messages.size <= 1 && !isGenerating) {
        item {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Try", color = TextMuted, fontSize = 12.sp)
            SUGGESTIONS.forEach { s ->
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(8.dp))
                  .border(1.dp, ObsidianBorder, RoundedCornerShape(8.dp))
                  .clickable { submit(s) }
                  .padding(horizontal = 12.dp, vertical = 10.dp)
              ) {
                Text(s, color = TextSecondary, fontSize = 13.sp)
              }
            }
          }
        }
      }
    }

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.Bottom
    ) {
      OutlinedTextField(
        value = inputText,
        onValueChange = { inputText = it },
        modifier = Modifier.weight(1f),
        placeholder = { Text("Describe an app or ask a question", color = TextMuted, fontSize = 14.sp) },
        maxLines = 5,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedTextColor = TextPrimary,
          unfocusedTextColor = TextPrimary,
          focusedBorderColor = CyberCyanPrimary,
          unfocusedBorderColor = ObsidianBorder,
          cursorColor = CyberCyanPrimary,
          focusedContainerColor = ObsidianSurface,
          unfocusedContainerColor = ObsidianSurface
        )
      )
      Spacer(modifier = Modifier.width(8.dp))
      IconButton(
        onClick = { if (isGenerating) orchestrator.stop() else submit(inputText) },
        enabled = isGenerating || inputText.isNotBlank(),
        colors = IconButtonDefaults.iconButtonColors(
          containerColor = CyberCyanPrimary,
          contentColor = Color.Black,
          disabledContainerColor = ObsidianSurfaceVariant,
          disabledContentColor = TextMuted
        ),
        modifier = Modifier.size(48.dp)
      ) {
        Icon(
          imageVector = if (isGenerating) Icons.Default.Stop else Icons.AutoMirrored.Filled.Send,
          contentDescription = if (isGenerating) "Stop" else "Send"
        )
      }
    }
  }
}

@Composable
private fun MessageItem(
  message: ChatMessage,
  telemetry: TelemetryData,
  canPreview: Boolean,
  onApply: () -> Unit,
  onDiscard: () -> Unit,
  onPreview: () -> Unit,
  onApplyPatch: (com.example.data.model.PatchProposal) -> Unit
) {
  when (message.sender) {
    MessageSender.USER -> Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
      Box(
        modifier = Modifier
          .widthIn(max = 300.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(ObsidianSurfaceVariant)
          .padding(horizontal = 12.dp, vertical = 8.dp)
      ) {
        Text(message.content, color = TextPrimary, fontSize = 14.sp, lineHeight = 20.sp)
      }
    }

    MessageSender.AGENT -> Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
      val shown = remember(message.content) { FileBlocks.displayText(message.content) }
      if (shown.isNotEmpty()) MarkdownText(shown)
      if (message.isStreaming) StatusLine(telemetry)
      if (message.fileChanges.isNotEmpty()) {
        FileChangesCard(
          changes = message.fileChanges,
          canPreview = canPreview,
          onApply = onApply,
          onDiscard = onDiscard,
          onPreview = onPreview
        )
      }
      message.patchProposal?.let { patch ->
        Text(patch.relativePath, color = TextSecondary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        DiffViewer(diffLines = patch.diffLines)
        if (!patch.isApplied) {
          Button(
            onClick = { onApplyPatch(patch) },
            colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.Black)
          ) { Text("Apply patch", fontSize = 13.sp) }
        }
      }
    }

    else -> {
      val label = message.toolCall?.let { "${it.toolName} · ${it.status}" } ?: message.content
      Text(label, color = TextMuted, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
    }
  }
}

@Composable
private fun StatusLine(t: TelemetryData) {
  val text = if (t.outputTokens == 0) {
    "Reading prompt · ${t.inputTokens} tokens"
  } else {
    "Writing · ${"%.1f".format(t.tokensPerSecond)} tok/s"
  }
  Row(verticalAlignment = Alignment.CenterVertically) {
    CircularProgressIndicator(modifier = Modifier.size(12.dp), strokeWidth = 1.5.dp, color = TextMuted)
    Spacer(modifier = Modifier.width(8.dp))
    Text(text, color = TextMuted, fontSize = 12.sp)
  }
}
