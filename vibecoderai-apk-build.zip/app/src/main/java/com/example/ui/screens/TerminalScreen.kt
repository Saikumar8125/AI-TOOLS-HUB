package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Project
import com.example.terminal.TerminalExecutionResult
import com.example.terminal.TerminalManager
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

data class TerminalLogEntry(
  val command: String,
  val result: TerminalExecutionResult?,
  val isRunning: Boolean = false
)

@Composable
fun TerminalScreen(
  terminalManager: TerminalManager,
  activeProject: Project?,
  modifier: Modifier = Modifier
) {
  val scope = rememberCoroutineScope()
  var inputCommand by remember { mutableStateOf("") }
  val history = remember { mutableStateListOf<TerminalLogEntry>() }
  var currentJob by remember { mutableStateOf<Job?>(null) }
  val listState = rememberLazyListState()

  LaunchedEffect(history.size) {
    if (history.isNotEmpty()) {
      listState.animateScrollToItem(history.size - 1)
    }
  }

  fun runCommand(cmd: String) {
    if (cmd.isBlank() || activeProject == null || currentJob?.isActive == true) return
    val entry = TerminalLogEntry(command = cmd, result = null, isRunning = true)
    history.add(entry)
    val entryIdx = history.lastIndex

    currentJob = scope.launch {
      val res = terminalManager.executeCommand(cmd, activeProject.rootDir)
      history[entryIdx] = TerminalLogEntry(command = cmd, result = res, isRunning = false)
      currentJob = null
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFF030712))
  ) {
    // Terminal Top Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(ObsidianSurface)
        .padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.Terminal,
          contentDescription = null,
          tint = CyberCyanPrimary,
          modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "Sandboxed Terminal",
          color = TextPrimary,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "• ${activeProject?.name ?: "No Workspace"}",
          color = TextMuted,
          fontSize = 11.sp,
          fontFamily = FontFamily.Monospace
        )
      }

      Row(verticalAlignment = Alignment.CenterVertically) {
        if (currentJob?.isActive == true) {
          IconButton(
            onClick = {
              currentJob?.cancel()
              currentJob = null
            },
            modifier = Modifier.size(32.dp)
          ) {
            Icon(imageVector = Icons.Default.Stop, contentDescription = "Cancel", tint = Color(0xFFF85149))
          }
        }
        IconButton(
          onClick = { history.clear() },
          modifier = Modifier.size(32.dp)
        ) {
          Icon(imageVector = Icons.Default.ClearAll, contentDescription = "Clear", tint = TextMuted)
        }
      }
    }

    // Scrollback Console Output
    LazyColumn(
      state = listState,
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 6.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      if (history.isEmpty()) {
        item {
          Text(
            text = "VibeCoderAI Sandboxed Shell [Version 1.0.0]\nWorkspace restricted to: ${activeProject?.rootPath ?: "~"}\nType a command or pick from suggestions below.",
            color = TextMuted,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            lineHeight = 16.sp
          )
        }
      }

      items(history) { entry ->
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(ObsidianSurface)
            .padding(8.dp)
        ) {
          // Command Line Prompt
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "$ ",
              color = CyberCyanPrimary,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              fontFamily = FontFamily.Monospace
            )
            Text(
              text = entry.command,
              color = TextPrimary,
              fontWeight = FontWeight.SemiBold,
              fontSize = 12.sp,
              fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.weight(1f))
            if (entry.isRunning) {
              CircularProgressIndicator(
                modifier = Modifier.size(12.dp),
                strokeWidth = 1.5.dp,
                color = CyberCyanPrimary
              )
            } else entry.result?.let { res ->
              val isOk = res.exitCode == 0
              Text(
                text = "exit ${res.exitCode} (${res.durationMs}ms)",
                color = if (isOk) CyberGreenSuccess else Color(0xFFF85149),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          }

          // Stdout Output
          entry.result?.stdout?.takeIf { it.isNotEmpty() }?.let { out ->
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = out,
              color = Color(0xFFE6EDF3),
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace,
              lineHeight = 15.sp
            )
          }

          // Stderr Output
          entry.result?.stderr?.takeIf { it.isNotEmpty() }?.let { err ->
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = err,
              color = Color(0xFFFFA198),
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace,
              lineHeight = 15.sp
            )
          }
        }
      }
    }

    // Quick Command Suggestions
    LazyRow(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 4.dp),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      val suggestions = listOf("ls -la", "pwd", "git status", "find .", "cat build.gradle.kts")
      items(suggestions) { cmd ->
        FilterChip(
          selected = false,
          onClick = {
            inputCommand = cmd
            runCommand(cmd)
          },
          label = { Text(cmd, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = TextPrimary) },
          colors = FilterChipDefaults.filterChipColors(containerColor = ObsidianSurfaceVariant),
          border = FilterChipDefaults.filterChipBorder(enabled = true, selected = false, borderColor = ObsidianBorder)
        )
      }
    }

    // Input Execution Line
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(ObsidianSurface)
        .padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "user@vibecoder:~$ ",
        color = CyberCyanPrimary,
        fontSize = 12.sp,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold
      )
      OutlinedTextField(
        value = inputCommand,
        onValueChange = { inputCommand = it },
        placeholder = { Text("enter command...", fontSize = 12.sp, color = TextMuted) },
        singleLine = true,
        modifier = Modifier
          .weight(1f)
          .testTag("terminal_input_field"),
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = Color.Transparent,
          unfocusedContainerColor = Color.Transparent,
          focusedBorderColor = Color.Transparent,
          unfocusedBorderColor = Color.Transparent,
          focusedTextColor = TextPrimary,
          unfocusedTextColor = TextPrimary
        ),
        textStyle = MaterialTheme.typography.bodySmall.copy(
          fontFamily = FontFamily.Monospace,
          fontSize = 12.sp
        )
      )
      IconButton(
        onClick = {
          val cmd = inputCommand
          inputCommand = ""
          runCommand(cmd)
        },
        enabled = inputCommand.isNotBlank() && currentJob?.isActive != true,
        modifier = Modifier
          .size(36.dp)
          .clip(RoundedCornerShape(6.dp))
          .background(if (inputCommand.isNotBlank()) CyberCyanPrimary else ObsidianSurfaceVariant)
          .testTag("terminal_run_button")
      ) {
        Icon(
          imageVector = Icons.Default.PlayArrow,
          contentDescription = "Execute",
          tint = if (inputCommand.isNotBlank()) Color.Black else TextMuted
        )
      }
    }
  }
}
