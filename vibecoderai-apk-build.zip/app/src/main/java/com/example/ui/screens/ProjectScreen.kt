package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FileItem
import com.example.data.model.Project
import com.example.data.model.ProjectType
import com.example.project.ProjectManager
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun ProjectScreen(
  projectManager: ProjectManager,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val projects by projectManager.projects.collectAsState()
  val activeProject by projectManager.activeProject.collectAsState()

  var showNewProjectDialog by remember { mutableStateOf(false) }
  var showRenameDialog by remember { mutableStateOf(false) }
  var showDeleteDialog by remember { mutableStateOf(false) }
  var showImportZipDialog by remember { mutableStateOf(false) }

  var selectedFile by remember { mutableStateOf<File?>(null) }
  var fileEditorContent by remember { mutableStateOf("") }
  var isFileDirty by remember { mutableStateOf(false) }

  val expandedFolders = remember { mutableStateMapOf<String, Boolean>() }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    // Project Header Toolbar
    ProjectToolbar(
      activeProject = activeProject,
      projects = projects,
      onSelectProject = { scope.launch { projectManager.selectProject(it) } },
      onNewProject = { showNewProjectDialog = true },
      onImportZip = { showImportZipDialog = true },
      onRenameProject = { showRenameDialog = true },
      onDeleteProject = { showDeleteDialog = true },
      onExportZip = {
        activeProject?.let { proj ->
          scope.launch {
            try {
              val zip = projectManager.exportProjectToZip(proj)
              Toast.makeText(context, "Exported ZIP: ${zip.name} (${zip.length()} bytes)", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
              Toast.makeText(context, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
          }
        }
      }
    )

    // Main workspace content: Split between File Explorer and File Editor
    Row(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
    ) {
      // Left Pane: File Tree Explorer
      Card(
        shape = RoundedCornerShape(0.dp),
        colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
        modifier = Modifier
          .weight(0.42f)
          .fillMaxSize()
      ) {
        Column(modifier = Modifier.padding(8.dp)) {
          Text(
            text = "EXPLORER",
            color = TextMuted,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 6.dp)
          )

          if (activeProject != null) {
            val rootItem = remember(activeProject?.rootPath, activeProject?.updatedAt) {
              projectManager.getFileTree(activeProject!!.rootDir)
            }

            LazyColumn(modifier = Modifier.fillMaxSize()) {
              item {
                FileTreeItemView(
                  item = rootItem,
                  level = 0,
                  expandedMap = expandedFolders,
                  selectedFilePath = selectedFile?.absolutePath,
                  onFileClick = { item ->
                    if (!item.isDirectory) {
                      val file = File(item.path)
                      selectedFile = file
                      fileEditorContent = if (file.exists()) file.readText() else ""
                      isFileDirty = false
                    } else {
                      val current = expandedFolders[item.path] ?: false
                      expandedFolders[item.path] = !current
                    }
                  }
                )
              }
            }
          } else {
            Text(text = "No active project.", color = TextMuted, fontSize = 12.sp)
          }
        }
      }

      // Right Pane: File Code Editor
      Column(
        modifier = Modifier
          .weight(0.58f)
          .fillMaxSize()
          .background(Color(0xFF030712))
          .padding(8.dp)
      ) {
        if (selectedFile != null) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text(
                text = selectedFile!!.name,
                color = CyberCyanPrimary,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "${fileEditorContent.lines().size} lines • ${selectedFile!!.length()} bytes",
                color = TextMuted,
                fontSize = 10.sp
              )
            }
            Button(
              onClick = {
                selectedFile?.writeText(fileEditorContent)
                isFileDirty = false
                Toast.makeText(context, "Saved ${selectedFile?.name}", Toast.LENGTH_SHORT).show()
              },
              enabled = isFileDirty,
              colors = ButtonDefaults.buttonColors(
                containerColor = if (isFileDirty) CyberGreenSuccess else ObsidianSurfaceVariant,
                contentColor = if (isFileDirty) Color.Black else TextMuted
              ),
              shape = RoundedCornerShape(4.dp),
              modifier = Modifier.testTag("save_file_button")
            ) {
              Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Save", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }

          OutlinedTextField(
            value = fileEditorContent,
            onValueChange = {
              fileEditorContent = it
              isFileDirty = true
            },
            modifier = Modifier
              .fillMaxSize()
              .testTag("code_editor_field"),
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = Color.Transparent,
              unfocusedContainerColor = Color.Transparent,
              focusedBorderColor = ObsidianBorder,
              unfocusedBorderColor = Color.Transparent,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            textStyle = MaterialTheme.typography.bodySmall.copy(
              fontFamily = FontFamily.Monospace,
              fontSize = 11.sp,
              lineHeight = 16.sp
            )
          )
        } else {
          Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
              text = "Select a file from the explorer to view or edit.",
              color = TextMuted,
              fontSize = 12.sp
            )
          }
        }
      }
    }
  }

  // New Project Dialog
  if (showNewProjectDialog) {
    NewProjectDialog(
      onDismiss = { showNewProjectDialog = false },
      onCreate = { name, type, desc ->
        scope.launch {
          projectManager.createProject(name, type, desc)
          showNewProjectDialog = false
        }
      }
    )
  }

  // Rename Dialog
  if (showRenameDialog && activeProject != null) {
    RenameProjectDialog(
      currentName = activeProject!!.name,
      onDismiss = { showRenameDialog = false },
      onRename = { newName ->
        scope.launch {
          try {
            projectManager.renameProject(activeProject!!, newName)
            showRenameDialog = false
          } catch (e: Exception) {
            Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
          }
        }
      }
    )
  }

  // Delete Dialog
  if (showDeleteDialog && activeProject != null) {
    DeleteProjectDialog(
      projectName = activeProject!!.name,
      onDismiss = { showDeleteDialog = false },
      onConfirm = {
        scope.launch {
          projectManager.deleteProject(activeProject!!)
          showDeleteDialog = false
        }
      }
    )
  }

  // Import ZIP Dialog
  if (showImportZipDialog) {
    ImportZipDialog(
      onDismiss = { showImportZipDialog = false },
      onImport = { path, projName ->
        scope.launch {
          try {
            val file = File(path)
            if (!file.exists()) {
              Toast.makeText(context, "ZIP file not found: $path", Toast.LENGTH_SHORT).show()
              return@launch
            }
            projectManager.importProjectFromZip(file, projName)
            Toast.makeText(context, "Imported project '$projName'", Toast.LENGTH_SHORT).show()
            showImportZipDialog = false
          } catch (e: Exception) {
            Toast.makeText(context, "Import error: ${e.message}", Toast.LENGTH_LONG).show()
          }
        }
      }
    )
  }
}

@Composable
fun ProjectToolbar(
  activeProject: Project?,
  projects: List<Project>,
  onSelectProject: (Project) -> Unit,
  onNewProject: () -> Unit,
  onImportZip: () -> Unit,
  onRenameProject: () -> Unit,
  onDeleteProject: () -> Unit,
  onExportZip: () -> Unit
) {
  var showDropdown by remember { mutableStateOf(false) }

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(ObsidianSurfaceVariant)
      .padding(horizontal = 12.dp, vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Box {
      Row(
        modifier = Modifier
          .clip(RoundedCornerShape(6.dp))
          .background(ObsidianSurface)
          .clickable { showDropdown = true }
          .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(imageVector = Icons.Default.FolderOpen, contentDescription = null, tint = CyberCyanPrimary, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = activeProject?.name ?: "Select Project",
          color = TextPrimary,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace
        )
      }

      DropdownMenu(
        expanded = showDropdown,
        onDismissRequest = { showDropdown = false }
      ) {
        projects.forEach { proj ->
          DropdownMenuItem(
            text = { Text(proj.name, fontFamily = FontFamily.Monospace) },
            onClick = {
              onSelectProject(proj)
              showDropdown = false
            }
          )
        }
      }
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
      IconButton(onClick = onNewProject, modifier = Modifier.size(36.dp)) {
        Icon(imageVector = Icons.Default.Add, contentDescription = "New Project", tint = CyberCyanPrimary)
      }
      IconButton(onClick = onImportZip, modifier = Modifier.size(36.dp)) {
        Icon(imageVector = Icons.Default.Unarchive, contentDescription = "Import ZIP", tint = CyberCyanPrimary)
      }
      IconButton(onClick = onExportZip, modifier = Modifier.size(36.dp)) {
        Icon(imageVector = Icons.Default.Archive, contentDescription = "Export ZIP", tint = TextPrimary)
      }
      IconButton(onClick = onRenameProject, modifier = Modifier.size(36.dp)) {
        Icon(imageVector = Icons.Default.Edit, contentDescription = "Rename", tint = TextPrimary)
      }
      IconButton(onClick = onDeleteProject, modifier = Modifier.size(36.dp)) {
        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFF85149))
      }
    }
  }
}

@Composable
fun FileTreeItemView(
  item: FileItem,
  level: Int,
  expandedMap: Map<String, Boolean>,
  selectedFilePath: String?,
  onFileClick: (FileItem) -> Unit
) {
  val isExpanded = expandedMap[item.path] ?: false
  val isSelected = selectedFilePath == item.path

  Column {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(4.dp))
        .background(if (isSelected) ObsidianSurfaceVariant else Color.Transparent)
        .clickable { onFileClick(item) }
        .padding(start = (level * 12).dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = if (item.isDirectory) {
          if (isExpanded) Icons.Default.FolderOpen else Icons.Default.Folder
        } else Icons.Default.Description,
        contentDescription = null,
        tint = if (item.isDirectory) CyberCyanPrimary else TextMuted,
        modifier = Modifier.size(14.dp)
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = item.name,
        color = if (isSelected) CyberCyanPrimary else TextPrimary,
        fontSize = 11.sp,
        fontFamily = FontFamily.Monospace
      )
    }

    if (item.isDirectory && isExpanded) {
      item.children.forEach { child ->
        FileTreeItemView(
          item = child,
          level = level + 1,
          expandedMap = expandedMap,
          selectedFilePath = selectedFilePath,
          onFileClick = onFileClick
        )
      }
    }
  }
}

@Composable
fun NewProjectDialog(
  onDismiss: () -> Unit,
  onCreate: (name: String, type: ProjectType, description: String) -> Unit
) {
  var name by remember { mutableStateOf("MyAwesomeApp") }
  var selectedType by remember { mutableStateOf(ProjectType.ANDROID_COMPOSE) }
  var description by remember { mutableStateOf("Android Jetpack Compose project") }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = ObsidianSurface,
    title = { Text("Create New Project", color = TextPrimary, fontWeight = FontWeight.Bold) },
    text = {
      Column {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("Project Name") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text("Starter Template:", color = TextMuted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)

        ProjectType.values().forEach { type ->
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
              .fillMaxWidth()
              .clickable {
                selectedType = type
                description = "${type.displayName} project"
              }
              .padding(vertical = 2.dp)
          ) {
            RadioButton(
              selected = selectedType == type,
              onClick = { selectedType = type }
            )
            Spacer(modifier = Modifier.width(4.dp))
            Column {
              Text(type.displayName, color = TextPrimary, fontSize = 13.sp)
              Text("Extension: .${type.extensionHint}", color = TextMuted, fontSize = 10.sp)
            }
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { if (name.isNotBlank()) onCreate(name, selectedType, description) },
        colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.Black)
      ) {
        Text("Create Project", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss) { Text("Cancel") }
    }
  )
}

@Composable
fun RenameProjectDialog(
  currentName: String,
  onDismiss: () -> Unit,
  onRename: (String) -> Unit
) {
  var newName by remember { mutableStateOf(currentName) }
  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = ObsidianSurface,
    title = { Text("Rename Project", color = TextPrimary) },
    text = {
      OutlinedTextField(
        value = newName,
        onValueChange = { newName = it },
        label = { Text("New Name") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
      )
    },
    confirmButton = {
      Button(onClick = { if (newName.isNotBlank()) onRename(newName) }) { Text("Rename") }
    },
    dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Cancel") } }
  )
}

@Composable
fun DeleteProjectDialog(
  projectName: String,
  onDismiss: () -> Unit,
  onConfirm: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = ObsidianSurface,
    title = { Text("Delete Project?", color = Color(0xFFF85149)) },
    text = { Text("Are you sure you want to permanently delete project '$projectName'? This cannot be undone.", color = TextPrimary) },
    confirmButton = {
      Button(
        onClick = onConfirm,
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF85149), contentColor = Color.White)
      ) {
        Text("Delete Permanently")
      }
    },
    dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Cancel") } }
  )
}

@Composable
fun ImportZipDialog(
  onDismiss: () -> Unit,
  onImport: (zipPath: String, projectName: String) -> Unit
) {
  var projectName by remember { mutableStateOf("ImportedProject") }
  var zipPath by remember { mutableStateOf("") }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = ObsidianSurface,
    title = { Text("Import ZIP Project", color = TextPrimary, fontWeight = FontWeight.Bold) },
    text = {
      Column {
        Text("Provide project name and absolute ZIP archive path on device. Paths are protected against Zip Slip vulnerabilities.", color = TextMuted, fontSize = 12.sp)
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
          value = projectName,
          onValueChange = { projectName = it },
          label = { Text("Project Name") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
          value = zipPath,
          onValueChange = { zipPath = it },
          label = { Text("Absolute ZIP Path") },
          placeholder = { Text("/data/user/0/.../exports/app.zip") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { if (projectName.isNotBlank() && zipPath.isNotBlank()) onImport(zipPath, projectName) },
        colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.Black)
      ) {
        Text("Import", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Cancel") } }
  )
}
