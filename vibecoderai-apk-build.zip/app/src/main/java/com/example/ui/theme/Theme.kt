package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
  primary = CyberCyanPrimary,
  onPrimary = Color.Black,
  primaryContainer = CyberCyanContainer,
  onPrimaryContainer = Color(0xFFE0F2FE),
  secondary = CyberVioletSecondary,
  onSecondary = Color.Black,
  secondaryContainer = CyberVioletContainer,
  onSecondaryContainer = Color(0xFFEDE9FE),
  tertiary = CyberGreenSuccess,
  onTertiary = Color.Black,
  tertiaryContainer = CyberGreenContainer,
  onTertiaryContainer = Color(0xFFDCFCE7),
  background = ObsidianBackground,
  onBackground = TextPrimary,
  surface = ObsidianSurface,
  onSurface = TextPrimary,
  surfaceVariant = ObsidianSurfaceVariant,
  onSurfaceVariant = TextSecondary,
  outline = ObsidianBorder,
  error = CyberCoralError,
  onError = Color.Black,
  errorContainer = CyberCoralContainer,
  onErrorContainer = Color(0xFFFFEBE9)
)

private val LightColorScheme = darkColorScheme(
  primary = CyberCyanPrimary,
  onPrimary = Color.Black,
  primaryContainer = CyberCyanContainer,
  onPrimaryContainer = Color(0xFFE0F2FE),
  secondary = CyberVioletSecondary,
  onSecondary = Color.Black,
  secondaryContainer = CyberVioletContainer,
  onSecondaryContainer = Color(0xFFEDE9FE),
  tertiary = CyberGreenSuccess,
  background = ObsidianBackground,
  onBackground = TextPrimary,
  surface = ObsidianSurface,
  onSurface = TextPrimary,
  surfaceVariant = ObsidianSurfaceVariant,
  onSurfaceVariant = TextSecondary,
  outline = ObsidianBorder,
  error = CyberCoralError
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Keep developer cyber theme consistent
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = DarkColorScheme,
    typography = Typography,
    content = content
  )
}
