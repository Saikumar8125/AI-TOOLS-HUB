package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CodeBackground
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

private sealed interface Block {
  class Prose(val lines: List<String>) : Block
  class Code(val lang: String, val code: String) : Block
  class FileRef(val path: String) : Block
}

private val FILE_MARK = Regex("""^\[\[file:(.+)\]\]$""")
private val INLINE = Regex("""`([^`]+)`|\*\*([^*]+)\*\*""")

private fun parseBlocks(text: String): List<Block> {
  val out = mutableListOf<Block>()
  val prose = mutableListOf<String>()
  var inCode = false
  var lang = ""
  val code = StringBuilder()

  fun flushProse() {
    if (prose.isNotEmpty()) {
      out.add(Block.Prose(prose.toList()))
      prose.clear()
    }
  }

  for (line in text.lines()) {
    val t = line.trim()
    if (!inCode && t.startsWith("```")) {
      flushProse()
      inCode = true
      lang = t.removePrefix("```").trim()
      code.setLength(0)
      continue
    }
    if (inCode && t.startsWith("```")) {
      out.add(Block.Code(lang, code.toString().trimEnd('\n')))
      inCode = false
      continue
    }
    if (inCode) {
      code.append(line).append('\n')
      continue
    }
    val m = FILE_MARK.matchEntire(t)
    if (m != null) {
      flushProse()
      out.add(Block.FileRef(m.groupValues[1]))
    } else {
      prose.add(line)
    }
  }
  if (inCode) out.add(Block.Code(lang, code.toString().trimEnd('\n')))
  flushProse()
  return out
}

private fun inline(s: String): AnnotatedString = buildAnnotatedString {
  var last = 0
  for (m in INLINE.findAll(s)) {
    append(s.substring(last, m.range.first))
    val code = m.groups[1]?.value
    if (code != null) {
      withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = CodeBackground)) { append(code) }
    } else {
      withStyle(SpanStyle(fontWeight = FontWeight.SemiBold)) { append(m.groups[2]?.value ?: "") }
    }
    last = m.range.last + 1
  }
  append(s.substring(last))
}

/** Small markdown subset: headings, bullets, **bold**, `code`, fenced code blocks, and file markers. */
@Composable
fun MarkdownText(text: String, modifier: Modifier = Modifier) {
  val blocks = remember(text) { parseBlocks(text) }
  Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
    blocks.forEach { b ->
      when (b) {
        is Block.Prose -> ProseBlock(b.lines)
        is Block.Code -> CodeBlock(b.lang, b.code)
        is Block.FileRef -> FileRefRow(b.path)
      }
    }
  }
}

@Composable
private fun ProseBlock(lines: List<String>) {
  Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
    lines.forEach { raw ->
      val line = raw.trimEnd()
      val trimmed = line.trimStart()
      when {
        line.isBlank() -> Spacer(modifier = Modifier.height(2.dp))
        line.startsWith("### ") -> Text(inline(line.drop(4)), color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        line.startsWith("## ") -> Text(inline(line.drop(3)), color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        line.startsWith("# ") -> Text(inline(line.drop(2)), color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        trimmed.startsWith("- ") || trimmed.startsWith("* ") -> Row {
          Text("•", color = TextMuted, fontSize = 14.sp, modifier = Modifier.width(14.dp))
          Text(inline(trimmed.drop(2)), color = TextPrimary, fontSize = 14.sp, lineHeight = 20.sp)
        }
        else -> Text(inline(line), color = TextPrimary, fontSize = 14.sp, lineHeight = 20.sp)
      }
    }
  }
}

@Composable
fun CodeBlock(lang: String, code: String) {
  val clipboard = LocalClipboardManager.current
  var copied by remember { mutableStateOf(false) }
  val shape = RoundedCornerShape(8.dp)
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .clip(shape)
      .background(CodeBackground)
      .border(1.dp, ObsidianBorder, shape)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(start = 12.dp, end = 4.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = lang.ifBlank { "code" },
        color = TextMuted,
        fontSize = 11.sp,
        fontFamily = FontFamily.Monospace,
        modifier = Modifier.weight(1f)
      )
      TextButton(
        onClick = {
          clipboard.setText(AnnotatedString(code))
          copied = true
        },
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
      ) {
        Text(if (copied) "Copied" else "Copy", fontSize = 11.sp, color = TextSecondary)
      }
    }
    val highlighted = remember(code, lang) { SyntaxHighlighter.highlight(code, lang, TextPrimary) }
    Text(
      text = highlighted,
      color = TextPrimary,
      fontFamily = FontFamily.Monospace,
      fontSize = 12.sp,
      lineHeight = 17.sp,
      modifier = Modifier
        .horizontalScroll(rememberScrollState())
        .padding(start = 12.dp, end = 12.dp, bottom = 10.dp)
    )
  }
}

@Composable
private fun FileRefRow(path: String) {
  Row(
    modifier = Modifier
      .clip(RoundedCornerShape(6.dp))
      .background(ObsidianSurfaceVariant)
      .padding(horizontal = 10.dp, vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(Icons.Default.Description, contentDescription = null, tint = TextMuted, modifier = Modifier.size(14.dp))
    Spacer(modifier = Modifier.width(8.dp))
    Text(
      text = if (path == "...") "Writing file..." else path,
      color = TextSecondary,
      fontSize = 12.sp,
      fontFamily = FontFamily.Monospace
    )
  }
}
