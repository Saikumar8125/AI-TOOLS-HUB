package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PatchProposal
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

@Composable
fun PatchApprovalDialog(
  proposal: PatchProposal,
  onApprove: () -> Unit,
  onReject: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onReject,
    containerColor = ObsidianSurface,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.Security,
          contentDescription = "Security Approval",
          tint = CyberCyanPrimary,
          modifier = Modifier.padding(end = 8.dp)
        )
        Text(
          text = "Approve Surgical Patch",
          color = TextPrimary,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold
        )
      }
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text(
          text = "Target: ${proposal.relativePath} (Lines ${proposal.startLine}-${proposal.endLine})",
          color = CyberCyanPrimary,
          fontSize = 13.sp,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = proposal.rationale,
          color = TextMuted,
          fontSize = 13.sp
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = "Diff Preview:",
          color = TextPrimary,
          fontSize = 12.sp,
          fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(4.dp))
        DiffViewer(diffLines = proposal.diffLines)
      }
    },
    confirmButton = {
      Button(
        onClick = onApprove,
        colors = ButtonDefaults.buttonColors(containerColor = CyberGreenSuccess, contentColor = Color.Black)
      ) {
        Icon(imageVector = Icons.Default.Check, contentDescription = "Approve", modifier = Modifier.padding(end = 4.dp))
        Text("Approve & Apply", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      OutlinedButton(
        onClick = onReject,
        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMuted)
      ) {
        Icon(imageVector = Icons.Default.Close, contentDescription = "Reject", modifier = Modifier.padding(end = 4.dp))
        Text("Reject")
      }
    }
  )
}
