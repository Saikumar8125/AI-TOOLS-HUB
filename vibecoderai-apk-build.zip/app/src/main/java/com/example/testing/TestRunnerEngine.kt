package com.example.testing

import android.content.Context
import com.example.agent.ContextManager
import com.example.agent.tools.FilePatchTool
import com.example.agent.tools.FileReadTool
import com.example.agent.tools.FileWriteTool
import com.example.build.BuildRunner
import com.example.data.model.PatchProposal
import com.example.data.model.Project
import com.example.data.model.ProjectType
import com.example.data.model.SettingsState
import com.example.data.model.TestResult
import com.example.data.model.TestSuiteSummary
import com.example.llama.LlamaBridge
import com.example.security.SecurityManager
import com.example.terminal.TerminalManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class TestRunnerEngine(
  private val context: Context,
  private val securityManager: SecurityManager = SecurityManager(),
  private val buildRunner: BuildRunner = BuildRunner(),
  private val terminalManager: TerminalManager = TerminalManager()
) {

  suspend fun runAllTests(activeProject: Project?): List<TestResult> = withContext(Dispatchers.IO) {
    val results = mutableListOf<TestResult>()

    // Suite 1: Unit Tests
    results.addAll(runUnitTests())

    // Suite 2: Integration Tests
    results.addAll(runIntegrationTests(activeProject))

    // Suite 3: JNI Integration Tests
    results.addAll(runJniTests())

    // Suite 4: Model Loading Tests
    results.addAll(runModelLoadingTests())

    // Suite 5: Build Verification Tests
    results.addAll(runBuildVerificationTests(activeProject))

    results
  }

  fun summarizeTests(results: List<TestResult>): List<TestSuiteSummary> {
    return results.groupBy { it.suite }.map { (suite, list) ->
      val passed = list.count { it.passed }
      val failed = list.count { !it.passed }
      val totalTime = list.sumOf { it.durationMs }
      TestSuiteSummary(
        suiteName = suite,
        passed = passed,
        failed = failed,
        total = list.size,
        durationMs = totalTime
      )
    }
  }

  private fun runUnitTests(): List<TestResult> {
    val list = mutableListOf<TestResult>()

    // Test 1: Security Path Traversal
    val t1Start = System.currentTimeMillis()
    try {
      val root = File(context.filesDir, "test_root")
      val unsafeFile = File(root, "../../etc/passwd")
      val safeFile = File(root, "src/Main.kt")
      val isUnsafeBlocked = !securityManager.isPathSafe(unsafeFile, root)
      val isSafeAllowed = securityManager.isPathSafe(safeFile, root)
      val passed = isUnsafeBlocked && isSafeAllowed
      list.add(
        TestResult(
          suite = "Unit Tests",
          name = "SecurityManager: Path Traversal Isolation",
          passed = passed,
          durationMs = System.currentTimeMillis() - t1Start,
          details = "Confirmed traversal escape is blocked and safe paths are allowed."
        )
      )
    } catch (e: Exception) {
      list.add(TestResult("Unit Tests", "SecurityManager: Path Traversal Isolation", false, System.currentTimeMillis() - t1Start, e.message ?: "", e.stackTraceToString()))
    }

    // Test 2: Diff Line Generation
    val t2Start = System.currentTimeMillis()
    try {
      val diffs = PatchProposal.generateDiff("val x = 1", "val x = 2")
      val passed = diffs.size == 2 && diffs.any { it.content == "val x = 1" } && diffs.any { it.content == "val x = 2" }
      list.add(
        TestResult(
          suite = "Unit Tests",
          name = "PatchProposal: Diff Generator",
          passed = passed,
          durationMs = System.currentTimeMillis() - t2Start,
          details = "Diff successfully parsed 1 removed and 1 added line."
        )
      )
    } catch (e: Exception) {
      list.add(TestResult("Unit Tests", "PatchProposal: Diff Generator", false, System.currentTimeMillis() - t2Start, e.message ?: "", e.stackTraceToString()))
    }

    // Test 3: ContextManager Token Budget
    val t3Start = System.currentTimeMillis()
    try {
      val cm = ContextManager()
      val tokens = cm.countTokens("fun main() { println(\"Hello VibeCoder\") }")
      val passed = tokens > 0
      list.add(
        TestResult(
          suite = "Unit Tests",
          name = "ContextManager: Token Estimation",
          passed = passed,
          durationMs = System.currentTimeMillis() - t3Start,
          details = "Computed token count: $tokens tokens."
        )
      )
    } catch (e: Exception) {
      list.add(TestResult("Unit Tests", "ContextManager: Token Estimation", false, System.currentTimeMillis() - t3Start, e.message ?: "", e.stackTraceToString()))
    }

    return list
  }

  private suspend fun runIntegrationTests(project: Project?): List<TestResult> {
    val list = mutableListOf<TestResult>()
    val testProject = project ?: Project("tmp", "TestProj", File(context.cacheDir, "test_proj").apply { mkdirs() }.absolutePath, "Test", ProjectType.ANDROID_COMPOSE)

    // Test 1: File Write & Read Tool Integration
    val t1Start = System.currentTimeMillis()
    try {
      val writeTool = FileWriteTool(securityManager)
      val readTool = FileReadTool(securityManager)

      val writeRes = writeTool.execute(testProject, mapOf("path" to "test_integration.txt", "content" to "VibeCoderAI Integration 123"))
      val readRes = readTool.execute(testProject, mapOf("path" to "test_integration.txt"))

      val passed = writeRes.success && readRes.success && readRes.output.contains("VibeCoderAI Integration 123")
      list.add(
        TestResult(
          suite = "Integration Tests",
          name = "File Tools: Write & Read Pipeline",
          passed = passed,
          durationMs = System.currentTimeMillis() - t1Start,
          details = "FileWriteTool created file and FileReadTool successfully read content."
        )
      )
    } catch (e: Exception) {
      list.add(TestResult("Integration Tests", "File Tools: Write & Read Pipeline", false, System.currentTimeMillis() - t1Start, e.message ?: "", e.stackTraceToString()))
    }

    // Test 2: FilePatchTool Surgical Replacement
    val t2Start = System.currentTimeMillis()
    try {
      val patchTool = FilePatchTool(securityManager)
      val file = File(testProject.rootDir, "patch_target.txt").apply { writeText("line1\nTARGET_CHUNK\nline3") }

      val patchRes = patchTool.execute(
        testProject,
        mapOf("path" to "patch_target.txt", "target_chunk" to "TARGET_CHUNK", "replacement_chunk" to "REPLACED_SURGICAL")
      )

      val updatedText = file.readText()
      val passed = patchRes.success && updatedText.contains("REPLACED_SURGICAL") && updatedText.contains("line1") && !updatedText.contains("TARGET_CHUNK")
      list.add(
        TestResult(
          suite = "Integration Tests",
          name = "FilePatchTool: Surgical In-Place Patching",
          passed = passed,
          durationMs = System.currentTimeMillis() - t2Start,
          details = "Applied targeted replacement without touching other lines."
        )
      )
    } catch (e: Exception) {
      list.add(TestResult("Integration Tests", "FilePatchTool: Surgical In-Place Patching", false, System.currentTimeMillis() - t2Start, e.message ?: "", e.stackTraceToString()))
    }

    // Test 3: Terminal Sandboxed Execution
    val t3Start = System.currentTimeMillis()
    try {
      val result = terminalManager.executeCommand("echo 'HelloTerminal'", testProject.rootDir)
      val passed = result.exitCode == 0 && result.stdout.contains("HelloTerminal")
      list.add(
        TestResult(
          suite = "Integration Tests",
          name = "TerminalManager: Sandboxed Command Execution",
          passed = passed,
          durationMs = System.currentTimeMillis() - t3Start,
          details = "Stdout captured '${result.stdout}', exit code: ${result.exitCode}."
        )
      )
    } catch (e: Exception) {
      list.add(TestResult("Integration Tests", "TerminalManager: Sandboxed Command Execution", false, System.currentTimeMillis() - t3Start, e.message ?: "", e.stackTraceToString()))
    }

    return list
  }

  private fun runJniTests(): List<TestResult> {
    val list = mutableListOf<TestResult>()
    val tStart = System.currentTimeMillis()
    try {
      val bridge = LlamaBridge.instance
      val info = bridge.getModelInfo()
      val tokens = bridge.tokenize("Test prompt for llama JNI")
      val passed = tokens.isNotEmpty()
      list.add(
        TestResult(
          suite = "JNI Tests",
          name = "llama.cpp JNI Bridge Loading & Tokenizer",
          passed = passed,
          durationMs = System.currentTimeMillis() - tStart,
          details = "Native status: ${if (LlamaBridge.isNativeLoaded) "Loaded libllama-android.so" else "Native library NOT loaded"}. Info: $info"
        )
      )
    } catch (e: Exception) {
      list.add(TestResult("JNI Tests", "llama.cpp JNI Bridge Loading & Tokenizer", false, System.currentTimeMillis() - tStart, e.message ?: "", e.stackTraceToString()))
    }
    return list
  }

  private fun runModelLoadingTests(): List<TestResult> {
    val list = mutableListOf<TestResult>()
    val tStart = System.currentTimeMillis()
    try {
      val models = SettingsState.AVAILABLE_MODELS
      val validModels = models.all { it.sizeMb > 0 && it.contextTokens >= 2048 && it.fileName.endsWith(".gguf") }
      list.add(
        TestResult(
          suite = "Model Tests",
          name = "GGUF Model Presets & Parameter Bounds",
          passed = validModels,
          durationMs = System.currentTimeMillis() - tStart,
          details = "Verified ${models.size} GGUF model descriptors with valid quantization and context length."
        )
      )
    } catch (e: Exception) {
      list.add(TestResult("Model Tests", "GGUF Model Presets & Parameter Bounds", false, System.currentTimeMillis() - tStart, e.message ?: "", e.stackTraceToString()))
    }

    // Test GgufReader binary parsing
    val tGgufStart = System.currentTimeMillis()
    try {
      val reader = com.example.llama.GgufReader()
      val testFile = File(context.cacheDir, "test_model.gguf")
      reader.writeValidGgufFile(testFile, version = 3, tensorCount = 290, kvCount = 32)
      val header = reader.readHeader(testFile)
      val passed = header.isValid && header.magic == "GGUF" && header.tensorCount == 290L
      list.add(
        TestResult(
          suite = "Model Tests",
          name = "GgufReader: Binary Header & Magic Validation",
          passed = passed,
          durationMs = System.currentTimeMillis() - tGgufStart,
          details = "GGUF container parsed successfully. Magic: ${header.magic}, Version: ${header.version}, Tensors: ${header.tensorCount}."
        )
      )
    } catch (e: Exception) {
      list.add(TestResult("Model Tests", "GgufReader: Binary Header & Magic Validation", false, System.currentTimeMillis() - tGgufStart, e.message ?: "", e.stackTraceToString()))
    }

    return list
  }

  private suspend fun runBuildVerificationTests(project: Project?): List<TestResult> {
    val list = mutableListOf<TestResult>()
    val t1Start = System.currentTimeMillis()
    try {
      val rawLogs = "e: /app/MainActivity.kt:25:10: Unresolved reference: testVariable\n/app/Helper.java:12: error: cannot find symbol"
      val parsed = buildRunner.parseCompilationLogs(rawLogs)
      val passed = parsed.size == 2 && parsed[0].lineNumber == 25 && parsed[0].errorMessage.contains("Unresolved reference")
      list.add(
        TestResult(
          suite = "Build Verification",
          name = "BuildRunner: Error Log Parser (Kotlin & Java)",
          passed = passed,
          durationMs = System.currentTimeMillis() - t1Start,
          details = "Parsed ${parsed.size} compilation errors with exact file, line, and message."
        )
      )
    } catch (e: Exception) {
      list.add(TestResult("Build Verification", "BuildRunner: Error Log Parser (Kotlin & Java)", false, System.currentTimeMillis() - t1Start, e.message ?: "", e.stackTraceToString()))
    }

    if (project != null) {
      val t2Start = System.currentTimeMillis()
      try {
        val isGradle = buildRunner.isGradleProject(project)
        val passed = isGradle || project.type != ProjectType.ANDROID_COMPOSE
        list.add(
          TestResult(
            suite = "Build Verification",
            name = "Project Gradle Detection",
            passed = passed,
            durationMs = System.currentTimeMillis() - t2Start,
            details = "Gradle project detected: $isGradle for project ${project.name}."
          )
        )
      } catch (e: Exception) {
        list.add(TestResult("Build Verification", "Project Gradle Detection", false, System.currentTimeMillis() - t2Start, e.message ?: "", e.stackTraceToString()))
      }
    }
    return list
  }
}
