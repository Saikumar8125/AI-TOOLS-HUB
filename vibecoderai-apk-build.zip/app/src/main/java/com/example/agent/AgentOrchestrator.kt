package com.example.agent

import android.content.Context
import com.example.data.model.ChangeStatus
import com.example.data.model.ChatMessage
import com.example.data.model.FileChange
import com.example.data.model.MessageSender
import com.example.data.model.PatchProposal
import com.example.data.model.Project
import com.example.data.model.SettingsState
import com.example.data.model.TelemetryData
import com.example.data.model.ToolCallInfo
import com.example.llama.LlamaEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class AgentOrchestrator(
  private val context: Context,
  private val llamaEngine: LlamaEngine,
  private val toolExecutor: ToolExecutor = ToolExecutor(),
  private val contextManager: ContextManager = ContextManager(),
  private val selfRepairEngine: SelfRepairEngine = SelfRepairEngine()
) {

  private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
  val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

  private val _telemetry = MutableStateFlow(TelemetryData())
  val telemetry: StateFlow<TelemetryData> = _telemetry.asStateFlow()

  private val _pendingPatch = MutableStateFlow<PatchProposal?>(null)
  val pendingPatch: StateFlow<PatchProposal?> = _pendingPatch.asStateFlow()

  private val _isGenerating = MutableStateFlow(false)
  val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

  init {
    _messages.value = listOf(
      ChatMessage(
        id = UUID.randomUUID().toString(),
        sender = MessageSender.AGENT,
        content = "Describe an app and I will write it. Everything runs offline on this phone."
      )
    )
  }

  private var job: Job? = null

  /** Clears the conversation (keeps the welcome message). */
  fun newChat() {
    if (!_isGenerating.value) _messages.value = _messages.value.take(1)
  }

  /** Restores saved history on startup (only if the chat is still untouched). */
  fun restore(history: List<ChatMessage>) {
    if (history.isEmpty() || _messages.value.size > 1 || _isGenerating.value) return
    _messages.value = _messages.value.take(1) + history.filter { it.id != _messages.value[0].id }.map { it.copy(isStreaming = false) }
  }

  /** Cancels the running generation (also stops the native model). */
  fun stop() {
    job?.cancel()
  }

  fun sendMessage(
    userText: String,
    project: Project?,
    settings: SettingsState,
    scope: CoroutineScope
  ) {
    if (userText.isBlank() || _isGenerating.value) return

    _messages.value = _messages.value + ChatMessage(
      id = UUID.randomUUID().toString(),
      sender = MessageSender.USER,
      content = userText
    )
    _isGenerating.value = true
    job = scope.launch(Dispatchers.IO) {
      processAgentResponse(userText, project, settings)
    }
  }

  /** Token-lean prompt: the task plus the current project files (which already hold all state, so no chat history). */
  private fun buildPrompt(userText: String, project: Project?, settings: SettingsState): String {
    val promptTokens = (settings.contextLength - settings.maxOutputTokens - 350).coerceAtLeast(300)
    val snapshotBudget = (promptTokens * 3 - userText.length - 100).coerceIn(0, 9000)
    val snapshot = if (project != null && snapshotBudget > 200) ProjectFiles.snapshot(project.rootDir, snapshotBudget) else ""
    return buildString {
      if (snapshot.isNotBlank()) append("Current project files:\n").append(snapshot).append("\n")
      append("Task: ").append(userText)
    }
  }

  private suspend fun processAgentResponse(
    userText: String,
    project: Project?,
    settings: SettingsState
  ) {
    val agentMsgId = UUID.randomUUID().toString()
    _messages.value = _messages.value + ChatMessage(
      id = agentMsgId,
      sender = MessageSender.AGENT,
      content = "",
      isStreaming = true
    )

    val buffer = StringBuilder()
    try {
      llamaEngine.generateCompletionStream(
        prompt = buildPrompt(userText, project, settings),
        settings = settings,
        onTelemetryUpdate = { data -> _telemetry.value = data }
      ).collect { chunk ->
        buffer.append(chunk)
        updateMessageContent(agentMsgId, buffer.toString(), isStreaming = true)
      }
    } catch (e: kotlinx.coroutines.CancellationException) {
      buffer.append("\n\n[Stopped]")
      throw e
    } catch (t: Throwable) {
      buffer.append("\n\n[Error: ${t.javaClass.simpleName}: ${t.message}]")
    } finally {
      if (buffer.isEmpty()) buffer.append("[The model returned no text.]")
      finishMessage(agentMsgId, buffer.toString(), project, settings)
      _isGenerating.value = false
    }
  }

  /** Extracts file blocks from the reply and applies them (new files directly, overwrites after approval). */
  private fun finishMessage(id: String, text: String, project: Project?, settings: SettingsState) {
    val changes = if (project == null) emptyList() else FileBlocks.parse(text).map { p ->
      val target = ProjectFiles.resolve(project.rootDir, p.path)
      FileChange(path = p.path, content = p.content, isNew = target == null || !target.exists())
    }
    val autoApply = project != null && changes.isNotEmpty() &&
      (changes.all { it.isNew } || !settings.requireApprovalForDestructive)
    val finalChanges = if (autoApply) writeChanges(project!!, changes) else changes
    _messages.value = _messages.value.map { m ->
      if (m.id == id) m.copy(content = text, isStreaming = false, fileChanges = finalChanges) else m
    }
  }

  private fun writeChanges(project: Project, changes: List<FileChange>): List<FileChange> =
    changes.map { c ->
      if (c.status != ChangeStatus.PENDING) c
      else ProjectFiles.write(project.rootDir, c).fold(
        onSuccess = { c.copy(status = ChangeStatus.APPLIED) },
        onFailure = { e -> c.copy(status = ChangeStatus.FAILED, error = e.message) }
      )
    }

  fun applyChanges(messageId: String, project: Project, scope: CoroutineScope) {
    scope.launch(Dispatchers.IO) {
      _messages.value = _messages.value.map { m ->
        if (m.id == messageId) m.copy(fileChanges = writeChanges(project, m.fileChanges)) else m
      }
    }
  }

  fun discardChanges(messageId: String) {
    _messages.value = _messages.value.map { m ->
      if (m.id == messageId) {
        m.copy(fileChanges = m.fileChanges.map { c ->
          if (c.status == ChangeStatus.PENDING) c.copy(status = ChangeStatus.DISCARDED) else c
        })
      } else m
    }
  }

  private suspend fun runBuildWorkflow(project: Project) {
    val buildMsgId = UUID.randomUUID().toString()
    _messages.value = _messages.value + ChatMessage(
      id = buildMsgId,
      sender = MessageSender.TOOL,
      content = "Executing Gradle build verification for '${project.name}'...",
      toolCall = ToolCallInfo("project_build", mapOf("project" to project.name), "running")
    )

    val toolResult = toolExecutor.executeTool("project_build", emptyMap(), project)
    val updatedToolCall = ToolCallInfo(
      toolName = "project_build",
      arguments = mapOf("project" to project.name),
      status = if (toolResult.success) "success" else "error",
      resultSummary = if (toolResult.success) "Build Successful" else "Build Failed"
    )

    _messages.value = _messages.value + ChatMessage(
      id = UUID.randomUUID().toString(),
      sender = MessageSender.AGENT,
      content = if (toolResult.success) {
        "Build succeeded!\n${toolResult.output}"
      } else {
        "Build failed. Found errors:\n${toolResult.error}\n\nSay 'repair' to run the 10-step Self-Repair Engine."
      },
      toolCall = updatedToolCall
    )
  }

  private suspend fun runSelfRepairWorkflow(project: Project, settings: SettingsState) {
    val buildRes = selfRepairEngine.rebuildAndVerify(project)

    if (buildRes.errors.isEmpty()) {
      _messages.value = _messages.value + ChatMessage(
        id = UUID.randomUUID().toString(),
        sender = MessageSender.AGENT,
        content = "Self-Repair Engine: No errors found in workspace. All source files compiled cleanly!"
      )
      return
    }

    val activeError = buildRes.errors.first()
    val patch = selfRepairEngine.generateTargetedPatch(activeError, project)

    if (patch != null) {
      _pendingPatch.value = patch
      _messages.value = _messages.value + ChatMessage(
        id = UUID.randomUUID().toString(),
        sender = MessageSender.AGENT,
        content = "Diagnosed error in ${patch.relativePath} at line ${patch.startLine}:\n" +
            "Error: ${activeError.errorMessage}\n" +
            "Rationale: ${patch.rationale}\n\n" +
            "I have prepared a targeted surgical patch. Please review the diff below and approve to apply:",
        patchProposal = patch
      )
    } else {
      _messages.value = _messages.value + ChatMessage(
        id = UUID.randomUUID().toString(),
        sender = MessageSender.AGENT,
        content = "Self-Repair Engine: Detected error '${activeError.errorMessage}', but unable to generate safe surgical patch automatically."
      )
    }
  }

  fun approveAndApplyPatch(proposal: PatchProposal, project: Project, scope: CoroutineScope) {
    scope.launch(Dispatchers.IO) {
      val success = selfRepairEngine.applyPatch(proposal, project)
      _pendingPatch.value = null

      if (success) {
        _messages.value = _messages.value + ChatMessage(
          id = UUID.randomUUID().toString(),
          sender = MessageSender.AGENT,
          content = "Patch successfully applied to ${proposal.relativePath}. Rebuilding to verify..."
        )
        // Verify rebuild
        val verifyBuild = selfRepairEngine.rebuildAndVerify(project)
        if (verifyBuild.errors.isEmpty()) {
          _messages.value = _messages.value + ChatMessage(
            id = UUID.randomUUID().toString(),
            sender = MessageSender.AGENT,
            content = "Verification PASSED: Project built cleanly without errors!"
          )
        } else {
          _messages.value = _messages.value + ChatMessage(
            id = UUID.randomUUID().toString(),
            sender = MessageSender.AGENT,
            content = "Verification FAILED: ${verifyBuild.errors.size} remaining error(s). Unresolved: ${verifyBuild.errors.first().errorMessage}"
          )
        }
      } else {
        _messages.value = _messages.value + ChatMessage(
          id = UUID.randomUUID().toString(),
          sender = MessageSender.AGENT,
          content = "Failed to apply patch to ${proposal.relativePath}."
        )
      }
    }
  }

  fun rejectPatch(proposal: PatchProposal) {
    _pendingPatch.value = null
    _messages.value = _messages.value + ChatMessage(
      id = UUID.randomUUID().toString(),
      sender = MessageSender.AGENT,
      content = "Patch proposal for ${proposal.relativePath} was declined by user."
    )
  }

  private fun updateMessageContent(id: String, newContent: String, isStreaming: Boolean) {
    _messages.value = _messages.value.map { msg ->
      if (msg.id == id) msg.copy(content = newContent, isStreaming = isStreaming) else msg
    }
  }
}
