package com.example.agent.tools

import com.example.data.model.Project
import com.example.security.SecurityManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class FilePatchTool(
  private val securityManager: SecurityManager = SecurityManager()
) : Tool {
  override val name = "file_patch"
  override val description = "Applies a targeted surgical search-and-replace patch to a file without rewriting the whole file."

  override suspend fun execute(project: Project, arguments: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
    val path = arguments["path"] ?: return@withContext ToolResult(false, "", "Missing 'path' parameter.")
    val targetChunk = arguments["target_chunk"] ?: return@withContext ToolResult(false, "", "Missing 'target_chunk' parameter.")
    val replacementChunk = arguments["replacement_chunk"] ?: return@withContext ToolResult(false, "", "Missing 'replacement_chunk' parameter.")

    val file = if (path.startsWith("/")) File(path) else File(project.rootDir, path)

    if (!securityManager.isPathSafe(file, project.rootDir)) {
      return@withContext ToolResult(false, "", "Security Violation: Patch blocked outside workspace.")
    }

    if (!file.exists()) {
      return@withContext ToolResult(false, "", "File does not exist: $path")
    }

    try {
      val originalText = file.readText()
      if (!originalText.contains(targetChunk)) {
        return@withContext ToolResult(
          success = false,
          output = "",
          error = "Target content was not found in file. Patch aborted to avoid unintended changes."
        )
      }

      // Check for multiple occurrences
      val occurrences = originalText.windowed(targetChunk.length).count { it == targetChunk }
      if (occurrences > 1) {
        return@withContext ToolResult(
          success = false,
          output = "",
          error = "Target content matches $occurrences locations in the file. Please provide a more unique target chunk."
        )
      }

      // Backup before patch
      val backupDir = File(project.rootDir, ".vibecoder_backups").apply { if (!exists()) mkdirs() }
      val backupFile = File(backupDir, "${file.name}.${System.currentTimeMillis()}.bak")
      file.copyTo(backupFile, overwrite = true)

      val patchedText = originalText.replace(targetChunk, replacementChunk)
      file.writeText(patchedText)

      ToolResult(
        success = true,
        output = "Surgical patch successfully applied to ${file.relativeTo(project.rootDir).path}."
      )
    } catch (e: Exception) {
      ToolResult(false, "", "Failed to apply patch: ${e.message}")
    }
  }
}
