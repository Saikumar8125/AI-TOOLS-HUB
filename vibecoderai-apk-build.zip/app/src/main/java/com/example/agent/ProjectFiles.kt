package com.example.agent

import com.example.data.model.FileChange
import java.io.File

/** Sandboxed file helpers: nothing ever leaves the project folder. */
object ProjectFiles {
  private const val MAX_FILE_BYTES = 512 * 1024
  private val TEXT_EXT = setOf("html", "htm", "css", "js", "json", "md", "txt", "svg", "kt", "py", "xml")
  private val SKIP_DIRS = setOf("node_modules", "build", ".git")

  /** Resolves a model-supplied relative path inside [root], or null if it is unsafe. */
  fun resolve(root: File, relative: String): File? {
    val rel = relative.replace('\\', '/').trim().removePrefix("./")
    if (rel.isEmpty() || rel.length > 120 || rel.startsWith("/")) return null
    if (rel.split('/').any { it.isEmpty() || it == ".." || it.startsWith(".") }) return null
    val file = File(root, rel)
    return try {
      if (file.canonicalPath.startsWith(root.canonicalPath + File.separator)) file else null
    } catch (_: Exception) {
      null
    }
  }

  fun write(root: File, change: FileChange): Result<Unit> = runCatching {
    val target = resolve(root, change.path) ?: throw IllegalArgumentException("Unsafe path: ${change.path}")
    if (change.content.toByteArray().size > MAX_FILE_BYTES) throw IllegalArgumentException("File too large")
    target.parentFile?.mkdirs()
    target.writeText(change.content)
  }

  /**
   * Compact project view for the prompt: file list, then full contents of small text files while the
   * character [budget] lasts. Keeps token use low and lets the model edit what already exists.
   */
  fun snapshot(root: File, budget: Int): String {
    if (!root.isDirectory) return ""
    val files = root.walkTopDown()
      .onEnter { it.name !in SKIP_DIRS && !it.name.startsWith(".") || it == root }
      .filter { it.isFile && !it.name.startsWith(".") }
      .take(40)
      .sortedBy { it.name }
      .toList()
    if (files.isEmpty()) return ""

    val sb = StringBuilder()
    var left = budget
    for (f in files) {
      val rel = f.relativeTo(root).invariantSeparatorsPath
      if (f.extension.lowercase() !in TEXT_EXT || f.length() > left) {
        sb.append("- ").append(rel).append(" (").append(f.length()).append(" B, not shown)\n")
        continue
      }
      val body = f.readText()
      left -= body.length
      sb.append("<file path=\"").append(rel).append("\">\n").append(body.trimEnd()).append("\n</file>\n")
    }
    return sb.toString()
  }
}
