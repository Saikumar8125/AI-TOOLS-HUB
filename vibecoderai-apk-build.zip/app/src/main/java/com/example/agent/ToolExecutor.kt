package com.example.agent

import com.example.agent.tools.BuildTool
import com.example.agent.tools.FilePatchTool
import com.example.agent.tools.FileReadTool
import com.example.agent.tools.FileSearchTool
import com.example.agent.tools.FileWriteTool
import com.example.agent.tools.TerminalTool
import com.example.agent.tools.Tool
import com.example.agent.tools.ToolResult
import com.example.data.model.Project
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ToolExecutor {

  private val tools: Map<String, Tool> = listOf(
    FileSearchTool(),
    FileReadTool(),
    FileWriteTool(),
    FilePatchTool(),
    TerminalTool(),
    BuildTool()
  ).associateBy { it.name }

  fun getAvailableTools(): List<Tool> = tools.values.toList()

  suspend fun executeTool(
    toolName: String,
    arguments: Map<String, String>,
    project: Project
  ): ToolResult = withContext(Dispatchers.IO) {
    val tool = tools[toolName]
      ?: return@withContext ToolResult(
        success = false,
        output = "",
        error = "Tool '$toolName' not found. Available tools: ${tools.keys.joinToString(", ")}"
      )

    try {
      tool.execute(project, arguments)
    } catch (e: Exception) {
      ToolResult(
        success = false,
        output = "",
        error = "Exception in tool '$toolName': ${e.message}"
      )
    }
  }
}
