package com.example.agent

import com.example.data.model.CompilationError
import com.example.data.model.Project
import com.example.llama.LlamaBridge
import java.io.File
import java.security.MessageDigest
import kotlin.math.max
import kotlin.math.min

class ContextManager {

  private val fileHashCache = mutableMapOf<String, String>()
  private val fileContentCache = mutableMapOf<String, String>()
  private val bridge = LlamaBridge.instance

  fun countTokens(text: String): Int {
    if (text.isEmpty()) return 0
    return bridge.tokenize(text).size
  }

  /**
   * Hashes file content with SHA-256 to avoid repeated reads and redundant context generation.
   */
  fun computeFileSha256(file: File): String {
    if (!file.exists()) return ""
    return try {
      val digest = MessageDigest.getInstance("SHA-256")
      val bytes = file.readBytes()
      val hashBytes = digest.digest(bytes)
      hashBytes.joinToString("") { "%02x".format(it) }
    } catch (_: Exception) {
      "${file.length()}_${file.lastModified()}"
    }
  }

  fun getFileContentCached(file: File): String {
    if (!file.exists()) return ""
    val hash = computeFileSha256(file)
    val cachedHash = fileHashCache[file.absolutePath]

    if (cachedHash == hash && fileContentCache.containsKey(file.absolutePath)) {
      return fileContentCache[file.absolutePath]!!
    }

    val text = file.readText()
    fileHashCache[file.absolutePath] = hash
    fileContentCache[file.absolutePath] = text
    return text
  }

  fun isFileUnchanged(file: File): Boolean {
    val currentHash = computeFileSha256(file)
    val cachedHash = fileHashCache[file.absolutePath]
    return cachedHash != null && cachedHash == currentHash
  }

  /**
   * Sliding-window context management: Trims context to fit within the token budget
   * while prioritizing the latest conversation history and critical directives.
   */
  fun applySlidingWindow(fullContext: String, maxTokens: Int): String {
    if (countTokens(fullContext) <= maxTokens) return fullContext

    val lines = fullContext.lines()
    val headerLines = lines.take(5) // preserve system role directives
    val remainingBudget = maxTokens - countTokens(headerLines.joinToString("\n"))

    val tailLines = mutableListOf<String>()
    var currentTokens = 0
    for (i in lines.indices.reversed()) {
      if (i < 5) break
      val line = lines[i]
      val lineTokens = countTokens(line) + 1
      if (currentTokens + lineTokens > remainingBudget) break
      tailLines.add(0, line)
      currentTokens += lineTokens
    }

    return (headerLines + listOf("[... older context trimmed for token efficiency ...]") + tailLines).joinToString("\n")
  }

  /**
   * Extracts targeted code context around an error or focus line,
   * avoiding full file dumps and saving massive amounts of tokens.
   */
  fun extractFocusedSnippet(file: File, targetLine: Int, windowSize: Int = 15): Pair<Int, String> {
    val fullText = getFileContentCached(file)
    val lines = fullText.lines()
    if (lines.isEmpty()) return Pair(1, "")

    val safeTarget = targetLine.coerceIn(1, lines.size)
    val startLine = max(1, safeTarget - windowSize)
    val endLine = min(lines.size, safeTarget + windowSize)

    val snippet = lines.subList(startLine - 1, endLine).mapIndexed { idx, line ->
      val lineNum = startLine + idx
      val marker = if (lineNum == safeTarget) ">>> " else "    "
      "$marker$lineNum | $line"
    }.joinToString("\n")

    return Pair(startLine, snippet)
  }

  /**
   * Assembles an optimized context prompt for the AI agent,
   * fitting strictly within the allowed contextLength.
   */
  fun assembleContextPrompt(
    project: Project,
    userQuery: String,
    error: CompilationError?,
    maxContextTokens: Int = 2048
  ): String {
    val sb = StringBuilder()
    sb.appendLine("Role: Expert Offline Software Engineer (VibeCoderAI)")
    sb.appendLine("Active Workspace: ${project.name} (${project.type.displayName})")

    if (error != null) {
      sb.appendLine("\n[Active Diagnostic Issue]")
      sb.appendLine("File: ${File(error.filePath).relativeTo(project.rootDir).path}")
      sb.appendLine("Line: ${error.lineNumber}, Column: ${error.columnNumber}")
      sb.appendLine("Message: ${error.errorMessage}")

      val targetFile = File(error.filePath)
      if (targetFile.exists()) {
        val (startLine, snippet) = extractFocusedSnippet(targetFile, error.lineNumber)
        sb.appendLine("Relevant Code Slice (Lines $startLine-${startLine + snippet.lines().size}):")
        sb.appendLine("```")
        sb.appendLine(snippet)
        sb.appendLine("```")
      }
    }

    sb.appendLine("\nUser Goal: $userQuery")

    val prompt = sb.toString()
    return applySlidingWindow(prompt, maxContextTokens)
  }
}
