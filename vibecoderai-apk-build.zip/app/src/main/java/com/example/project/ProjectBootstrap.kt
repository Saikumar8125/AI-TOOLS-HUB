package com.example.project

import com.example.data.model.Project
import com.example.data.model.ProjectType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val STOP_WORDS = setOf("the", "and", "for", "with", "make", "create", "build", "app", "please", "simple", "that", "this", "using")

/** Creates an empty web project named after the prompt (no template boilerplate to waste tokens on). */
suspend fun ProjectManager.createBlankWebProject(prompt: String): Project {
  val words = prompt.lowercase()
    .replace(Regex("[^a-z0-9 ]"), " ")
    .split(" ")
    .filter { it.length > 2 && it !in STOP_WORDS }
    .take(3)
  val base = if (words.isEmpty()) "web-app" else words.joinToString("-")
  val project = createProject("$base-${(100..999).random()}", ProjectType.WEB_HTML, prompt.take(120))
  withContext(Dispatchers.IO) {
    project.rootDir.listFiles()?.filter { !it.name.startsWith(".") }?.forEach { it.deleteRecursively() }
  }
  return project
}
